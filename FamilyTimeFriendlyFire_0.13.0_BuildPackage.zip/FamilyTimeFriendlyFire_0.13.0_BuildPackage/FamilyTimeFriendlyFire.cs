// FamilyTimeFriendlyFire.cs  v0.13.0  (BepInEx 5 + Harmony, Unity Mono)
//
// Что делает:
//  1) Каждый взмах топора при рубке и каждое копание лопатой бьют всех, кто попал
//     в линию удара (волчата, животные), через родную систему здоровья игры.
//  2) Свободный удар на клавишу (по умолчанию V) топором/лопатой по тому, что перед камерой.
//  3) Удар по волчице повышает её "нрав" (собственный счётчик мода, НЕ родная ярость игры).
//     Нрав падает со временем (RageDecaySeconds). Если к отходу ко сну она ещё злится,
//     к родной ярости добавляется 1 очко; если успокоилась - родная ярость не трогается,
//     и game over от ударов не наступает. Родная механика ухода за детьми не меняется.
//     Клавиша ResetRageKey (F8) вручную сбрасывает родную ярость, если сохранение застряло.
//  4) Раненый волчонок подаёт голос (звук берётся из набора звуков его шаблона).
//  5) Иногда волчица рычит на игрока (та же анимация и звук, что на кабана), и
//     игра сама зовёт свободных волчат к ней под защиту.
//  6) Убитое существо без собственного дропа оставляет мясо (берётся из предмета,
//     который уже дропают другие существа: pork_chop, chicken_drumstick).
//  7) Смерть волчонка - шок: волчица ахает и рычит, все волчата вздрагивают и
//     кучкуются (или разбегаются), несколько из них подают голос.
//  8) Ранения, лечение и страх: битый волчонок пока не вылечится скулит, медленно
//     восстанавливает здоровье (быстрее на руках и во сне) и какое-то время убегает от игрока.
//  9) Обида (нужен мод Uppies Please, но без него всё работает): ударенный волчонок сразу
//     перестаёт проситься на ручки, показывает значок обиды, подаёт голос, и новое желание
//     у него появится только через OffendedCooldown секунд.
//
// 10) Безопасность: game over отключён (NoGameOver), сон всегда проходит; за ночь родная
//     ярость волчицы падает на NightlyRageRelief. Сохранения, застрявшие на 3/3, загружаются.
// 11) Доверие и характеры: у каждого волчонка есть доверие к игроку (удары снижают, руки
//     повышают) и характер (храбрый/обычный/трусливый). От них зависят страх и обида.
//     Хранится в BepInEx/config/FamilyTimeFriendlyFire/<имя сохранения>.pups.txt.
// 12) Месть волчицы: разозлённая (нрав >= RevengeMinTemper) волчица рычит и кусает игрока
//     (1 здоровья, по умолчанию не смертельно; здоровье возвращается). KO и game over не вызывает.
// 13) Ночные налёты: вечером с шансом, растущим от числа раненых волчат, к лагерю выходит кабан.
// 14) Падения: бросок волчонка слабее (PupThrowSpeedMultiplier), а при приземлении он получает
//     урон от скорости и высоты падения (со склонов - больнее). Пороги настраиваются в [Falls].
// 15) Котёл ([Cauldron]): брошенный в горячий котёл волчонок мгновенно погибает (200 урона) вместо
//     того, чтобы париться. Волчица впадает в бешенство ([Fury]): рычит и кусает 45 секунд,
//     у волчат падает доверие, у остальных шок.
// 16) Совместимость с остальными модами: сброс ярости теперь на F10 (F8 занят Free Roam), характер
//     волчонка берётся из Pup Traits (Brave / Shy / Scared), если он установлен; частые строки лога
//     вынесены в [Debug] Verbose (по умолчанию выключено).
// 17) Мама и дети + связь с другими модами:
//     - ударенный волчонок бежит к маме за утешением; рядом с ней он лечится быстрее, успокаивается,
//       возвращает часть доверия, мама смотрит на него, над головой значок Mama (Uppies Please);
//     - мама выходит к игроку и отчитывает его: запускается готовая сцена Uppies Please
//       (BeginMomIntervention), а волчата бегут к маме;
//     - мама рычит, если игрок с топором/лопатой подходит к раненому или напуганному волчонку;
//     - Pups Wander: раненые и напуганные волчата не отпускаются бродить;
//     - Pup Traits: Clingy и Scared чаще бегут к маме, Violent может укусить в ответ.
// 18) Прогнать и бродячие щенки (перенесено из Savage с исправлением счётчиков):
//     - клавиша G ([Shoo]): волчонок убегает, мама рычит; после нескольких "прогнать" подряд он уходит
//       из семьи и становится бродячим;
//     - бродячие щенки НЕ считаются детьми: их нет в счётчике "N Children" слева и в счётчиках
//       "не спят / голодны", игра не выбирает их исполнителями команд, они бродят сами и не просятся на ручки;
//     - стоя смирно без топора/лопаты рядом с бродячим щенком или нося его на руках, доверие растёт,
//       и он возвращается в семью;
//     - если вся семья истреблена, через время по лесу бродят чужие щенки ([Strays]).
// 19) Здоровье и судьба волчицы:
//     - [MamaHp]: удары инструментами отнимают здоровье волчицы (20), оно восстанавливается;
//       при нуле она впадает в бешенство (бессмертна), если MamaCanDie = false (по умолчанию);
//     - [MamaCanDie] = true: смертельный удар убирает её из семьи НАВСЕГДА. Она уходит в лес, потом её
//       скрывают, её нельзя позвать (следование, команды, мод-сцены заблокированы). Это сохраняется.
//     - [MamaDeath] Mode = Remains (по умолчанию): она не уходит, а остаётся мясом на месте гибели (из него
//       варится суп в котле, как из любой дичи); Mode = WalkAway: уходит в лес и скрывается;
//     - сироты: часть волчат дичает (бродячие), часть уходит насовсем, остальные теряют доверие.
//       По ночам без мамы доверие ниже 20 -> дичание, у бродячих ниже 15 -> уход. Налёты кабанов чаще.
// 20) Тишина и безопасность:
//     - Red Menace ([Compat] RedMenaceWrath): его "месть волчицы" (телепорт к игроку, нокаут, game over)
//       по умолчанию отключена; режим Ours отключает её только для гибели волчат от нашего мода;
//     - ограничитель криков волчицы ([Mama] RoarMinIntervalSeconds) и запугивание: клавиша H с топором или
//       лопатой, наведясь на неё, либо 3 удара по ней за 15 секунд: она притихает ([Intimidate]);
//     - ограничитель "мама!" и "папа!" у волчат ([Speech]).
//
// Написано по сигнатурам из Assembly-CSharp.dll и UppiesPlease.dll.

using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using GAT;
using HarmonyLib;
using UnityEngine;
using UnityEngine.InputSystem;

namespace FamilyTimeFriendlyFire
{
    [BepInPlugin("local.familytime.friendlyfire", "Family Time - Friendly Fire", "0.13.0")]
    public class Plugin : BaseUnityPlugin
    {
        internal static Plugin Instance;
        internal static ManualLogSource Log;

        // --- урон ---
        internal static ConfigEntry<int> AxeDamage, ShovelDamage;
        internal static ConfigEntry<float> AxeBeamRadius, ShovelBeamRadius;
        internal static ConfigEntry<float> AxeHitDelay;
        internal static ConfigEntry<float> HitCooldown;
        // --- кого бьём ---
        internal static ConfigEntry<bool> HitPlayerFaction, HitPassive, HitHostile, HitCarried;
        // --- волчица: удары и ярость ---
        internal static ConfigEntry<bool> HitMama;
        internal static ConfigEntry<int> MamaRagePerHit;
        internal static ConfigEntry<float> MamaHitRadius, MamaCooldown;
        internal static ConfigEntry<float> RageDecaySeconds;
        internal static ConfigEntry<int> MaxTemper, ResetRageTo;
        internal static ConfigEntry<bool> BedtimeAngerAddsRage;
        internal static ConfigEntry<Key> ResetRageKey;
        // --- волчица: рык и защита ---
        internal static ConfigEntry<float> RoarChance;
        internal static ConfigEntry<bool> RoarOnMamaHit;
        internal static ConfigEntry<float> RoarMaxDistance, RoarClearDelay;
        // --- мясо ---
        internal static ConfigEntry<bool> MeatEnabled, MeatFromFamily, MeatFromOthers;
        internal static ConfigEntry<string> MeatTemplateName;
        internal static ConfigEntry<int> MeatMin, MeatExtra;
        // --- шок ---
        internal static ConfigEntry<bool> ShockEnabled, ShockOnAnyKill, ShockScatter;
        internal static ConfigEntry<float> ShockSeconds, ShockRoarChance;
        internal static ConfigEntry<int> ShockMaxSounds, ShockMamaRage;
        // --- ранения, лечение, страх ---
        internal static ConfigEntry<bool> InjuryEnabled, HealEnabled, FearEnabled;
        internal static ConfigEntry<float> WoundedFraction, WhimperSeconds;
        internal static ConfigEntry<float> RegenSeconds, CarriedRegenSeconds, RescanSeconds;
        internal static ConfigEntry<int> HealOnSleep;
        internal static ConfigEntry<float> FearSecondsPerHit, MaxFearSeconds, FearRadius, FleeSeconds, FleeCooldown;
        // --- обида (интеграция с Uppies Please) ---
        internal static ConfigEntry<bool> OffendedEnabled;
        internal static ConfigEntry<float> OffendedCooldown, OffendedIconSeconds, OffendedSoundDelay;
        internal static ConfigEntry<string> OffendedIcon, OffendedSounds;
        // --- безопасность ---
        internal static ConfigEntry<bool> NoGameOver;
        internal static ConfigEntry<int> NightlyRageRelief;
        // --- доверие и характеры ---
        internal static ConfigEntry<bool> TrustEnabled, TrustPersist, TemperamentEnabled;
        internal static ConfigEntry<float> TrustStart, TrustLossPerHit, TrustGainPerSecondCarried, TrustRegenPerSecond;
        internal static ConfigEntry<int> BravePercent, TimidPercent;
        // --- месть волчицы ---
        internal static ConfigEntry<bool> RevengeEnabled, RevengeNonLethal;
        internal static ConfigEntry<int> RevengeMinTemper, RevengeDamage, RevengeReleaseTemper, PupHitsPerTemper;
        internal static ConfigEntry<float> RevengeRange, RevengeCooldown, PlayerRegenSeconds;
        // --- ночные налёты ---
        internal static ConfigEntry<bool> RaidEnabled;
        internal static ConfigEntry<string> RaidTemplate;
        internal static ConfigEntry<float> RaidBaseChance, RaidPerWounded, RaidMaxChance, RaidDistance, RaidNightStartHour;
        internal static ConfigEntry<int> RaidCount;
        // --- котёл и бешенство ---
        internal static ConfigEntry<bool> FryEnabled, FryOnlyThrown;
        internal static ConfigEntry<int> FryDamage;
        internal static ConfigEntry<float> FryWindowSeconds, FuryDuration, FuryBiteCooldown, FuryTrustLoss;
        // --- мама и дети ---
        internal static ConfigEntry<float> SeekMamaChance, SeekMamaSeconds, SeekMamaDelay, ComfortDistance, ComfortTrust, NearMamaRegenFactor;
        internal static ConfigEntry<int> ComfortHeal;
        internal static ConfigEntry<float> MomStepInChance, MomStepInCooldown, MomStepInDelay;
        internal static ConfigEntry<bool> GuardEnabled, WanderCompat, ViolentBiteBack;
        internal static ConfigEntry<float> GuardRadius, GuardCooldown, PupBiteCooldown;
        // --- совместимость ---
        internal static ConfigEntry<bool> UsePupTraits, Verbose, LinkMods;
        // --- тишина, запугивание, Red Menace ---
        internal static ConfigEntry<float> RoarMinInterval, CowedSeconds, IntimidateRange, IntimidateWindow;
        internal static ConfigEntry<float> MamaGreetingMinSeconds, PlayerGreetingMinSeconds;
        internal static ConfigEntry<int> IntimidateHits;
        internal static ConfigEntry<bool> IntimidateEnabled, LimitGreetings;
        internal static ConfigEntry<Key> IntimidateKey;
        internal static ConfigEntry<string> RedMenaceWrath;
        // --- здоровье и судьба волчицы ---
        internal static ConfigEntry<bool> MamaHpEnabled, MamaCanDie;
        internal static ConfigEntry<string> MamaDeathMode;
        internal static ConfigEntry<int> RemainsMeatCount;
        internal static ConfigEntry<int> MamaMaxHp, MamaHealOnSleep;
        internal static ConfigEntry<float> MamaDamageMul, MamaRegenSeconds, HpAfterFuryFraction;
        internal static ConfigEntry<float> OrphanLeaveChance, OrphanFeralChance, OrphanTrustLoss, OrphanLeaveDelay;
        internal static ConfigEntry<float> MamaWalkAwayDistance, MamaHideDistance, RaidAbsentBonus;
        // --- прогнать / бродячие щенки ---
        internal static ConfigEntry<bool> ShooEnabled, StraysEnabled;
        internal static ConfigEntry<Key> ShooKey;
        internal static ConfigEntry<int> RunawayAfterShoos, StrayCount;
        internal static ConfigEntry<float> ShooReach, ShooRadius, ShooTrustLoss;
        internal static ConfigEntry<float> StrayDelaySeconds, StrayDistance, FeralFleeRadius, FeralFleeSeconds;
        internal static ConfigEntry<float> BefriendRadius, BefriendTrustPerSecond, BefriendTrust;
        // --- падения ---
        internal static ConfigEntry<bool> FallsEnabled;
        internal static ConfigEntry<float> PupThrowSpeedMultiplier, SafeFallSpeed, DamagePerSpeed, SafeFallHeight, DamagePerMeter, MaxFlightSeconds;
        // --- сообщения на экране ---
        internal static ConfigEntry<bool> ToastsEnabled;
        // --- звуки боли ---
        internal static ConfigEntry<bool> HurtSoundEnabled;
        internal static ConfigEntry<string> HurtSounds;
        // --- свободный удар ---
        internal static ConfigEntry<bool> EnableFreeSwing;
        internal static ConfigEntry<Key> AttackKey;
        internal static ConfigEntry<float> FreeSwingReach, FreeSwingRadius, FreeSwingCooldown;

        internal static ConfigEntry<bool> DebugLog;

        private float _nextSwing;

        private void Awake()
        {
            Instance = this;
            Log = Logger;

            AxeDamage = Config.Bind("Damage", "AxeDamage", 2, "Урон топора по живым существам (у волчат 10 HP)");
            ShovelDamage = Config.Bind("Damage", "ShovelDamage", 1, "Урон лопаты по живым существам");
            AxeBeamRadius = Config.Bind("Hit", "AxeBeamRadius", 0.45f, "Насколько широко топор задевает по бокам от линии удара");
            ShovelBeamRadius = Config.Bind("Hit", "ShovelBeamRadius", 0.35f, "То же для лопаты");
            AxeHitDelay = Config.Bind("Hit", "AxeHitDelay", 0.0f, "Задержка урона после начала взмаха топора (сек). 0 = сразу");
            HitCooldown = Config.Bind("Hit", "PerTargetCooldown", 0.6f, "Не бить одну и ту же цель чаще, чем раз в N секунд");

            HitPlayerFaction = Config.Bind("Targets", "HitPlayerFaction", true, "Бить фракцию PLAYER (волчата)");
            HitPassive = Config.Bind("Targets", "HitPassive", true, "Бить пассивных животных");
            HitHostile = Config.Bind("Targets", "HitHostile", true, "Бить враждебных");
            HitCarried = Config.Bind("Targets", "HitCarried", false, "Бить тех, кого игрок держит на руках");

            HitMama = Config.Bind("Mama", "HitMama", true, "Удар по волчице добавляет ей ярость");
            MamaRagePerHit = Config.Bind("Mama", "RagePerHit", 1, "На сколько очков нрава волчицы повышает один засчитанный удар");
            MaxTemper = Config.Bind("Mama", "MaxTemper", 3, "Максимум нрава волчицы");
            MamaHitRadius = Config.Bind("Mama", "HitRadius", 0.6f, "Радиус попадания по волчице");
            MamaCooldown = Config.Bind("Mama", "Cooldown", 10.0f, "Не чаще одного засчитанного удара по волчице за N секунд");
            RageDecaySeconds = Config.Bind("Mama", "RageDecaySeconds", 90.0f,
                "Через сколько секунд нрав волчицы падает на 1 (отсчёт от последнего удара)");
            BedtimeAngerAddsRage = Config.Bind("Mama", "BedtimeAngerAddsRage", true,
                "Если к отходу ко сну волчица ещё злится, к родной ярости (счётчик game over) добавляется 1 очко. Успокоилась - ничего не добавляется");
            ResetRageKey = Config.Bind("Mama", "ResetRageHotkey", Key.F10,
                "Клавиша ручного сброса родной ярости волчицы (если сохранение застряло на 3/3)");
            ResetRageTo = Config.Bind("Mama", "ResetRageTo", 0, "До какого значения (0..3) сбрасывать родную ярость по клавише");

            RoarChance = Config.Bind("Mama", "RoarChance", 0.5f,
                "Шанс (0..1), что после удара по волчонку волчица зарычит на игрока и позовёт свободных волчат к себе");
            RoarOnMamaHit = Config.Bind("Mama", "RoarOnMamaHit", true, "Рычать на игрока, если ударили её саму");
            RoarMaxDistance = Config.Bind("Mama", "RoarMaxDistance", 25f, "Дальше этого расстояния от игрока волчица не рычит");
            RoarClearDelay = Config.Bind("Mama", "RoarClearDelay", 3.5f, "Через сколько секунд после рыка она перестаёт смотреть на игрока");

            HurtSoundEnabled = Config.Bind("Sound", "HurtSoundEnabled", true, "Проигрывать голос раненому существу");
            HurtSounds = Config.Bind("Sound", "HurtSounds", "FLEE,EFFORT,WOOF",
                "Список звуковых групп по приоритету (IDLE, PLAYER_PROXIMITY, PAIN_SMALL, UPPIES, NOM, EFFORT, WOLF_MAMA_PROXIMITY, FLEE, WOOF, WAHOO). " +
                "Играется первая, которая есть у шаблона существа. PAIN_SMALL игра и так играет сама, если он есть.");

            MeatEnabled = Config.Bind("Meat", "Enabled", true, "Оставлять мясо после смерти");
            MeatFromFamily = Config.Bind("Meat", "FromFamily", true, "Мясо из убитых волчат");
            MeatFromOthers = Config.Bind("Meat", "FromOtherAnimals", true,
                "Мясо из остальных убитых существ, у которых в игре нет своего дропа мяса");
            MeatTemplateName = Config.Bind("Meat", "ItemNames", "pork_chop,chicken_drumstick",
                "Части названий предметов-мяса через запятую по приоритету (без учёта регистра). " +
                "Мод берёт первый, который уже есть среди дропов других существ. В игре это pork_chop, chicken_drumstick, fish_chunk");
            MeatMin = Config.Bind("Meat", "MinCount", 1, "Минимум кусков мяса за одну смерть");
            MeatExtra = Config.Bind("Meat", "ExtraCount", 3,
                "Количество кусков = max(MinCount, случайное 0..ExtraCount-1). При 3 получается 1-2 куска");

            ShockEnabled = Config.Bind("Shock", "Enabled", true, "Смерть волчонка шокирует волчицу и остальных волчат");
            ShockOnAnyKill = Config.Bind("Shock", "OnAnyKill", false, "Шок и от смерти других животных, не только волчат");
            ShockSeconds = Config.Bind("Shock", "Seconds", 6.0f, "Сколько секунд волчата кучкуются/разбегаются");
            ShockScatter = Config.Bind("Shock", "Scatter", false, "false = волчата сбиваются в кучу, true = разбегаются");
            ShockMaxSounds = Config.Bind("Shock", "MaxSounds", 6, "Сколько случайных волчат подадут голос испуга");
            ShockMamaRage = Config.Bind("Shock", "MamaRage", 0, "На сколько очков нрава повышается волчица за смерть волчонка (затухает как обычно)");
            ShockRoarChance = Config.Bind("Shock", "RoarChance", 1.0f, "Шанс (0..1), что волчица зарычит на игрока после смерти волчонка");

            InjuryEnabled = Config.Bind("Injury", "Enabled", true, "Раненый волчонок периодически скулит (анимация боли + голос)");
            WoundedFraction = Config.Bind("Injury", "WoundedFraction", 0.5f, "Волчонок считается раненым, если здоровье <= этой доли от максимума");
            WhimperSeconds = Config.Bind("Injury", "WhimperSeconds", 25.0f, "Как часто раненый волчонок скулит (сек, с разбросом)");

            HealEnabled = Config.Bind("Heal", "Enabled", true, "Волчата, которых ударил игрок, постепенно лечатся");
            RegenSeconds = Config.Bind("Heal", "RegenSeconds", 45.0f, "Секунд на 1 здоровья (голодные не лечатся)");
            CarriedRegenSeconds = Config.Bind("Heal", "CarriedRegenSeconds", 12.0f, "Секунд на 1 здоровья, пока волчонок на руках");
            HealOnSleep = Config.Bind("Heal", "HealOnSleep", 4, "Сколько здоровья восстанавливается во сне");
            RescanSeconds = Config.Bind("Heal", "RescanSeconds", 120.0f,
                "Как часто искать раненых волчат среди всех (после перезапуска игры список теряется; заодно лечатся и укушенные кабанами)");

            FearEnabled = Config.Bind("Fear", "Enabled", true, "Битый волчонок какое-то время боится игрока и убегает от него");
            FearSecondsPerHit = Config.Bind("Fear", "SecondsPerHit", 90.0f, "На сколько секунд каждый удар добавляет страх");
            MaxFearSeconds = Config.Bind("Fear", "MaxSeconds", 300.0f, "Верхний предел страха, сек");
            FearRadius = Config.Bind("Fear", "Radius", 4.0f, "Ближе этого расстояния до игрока напуганный волчонок убегает");
            FleeSeconds = Config.Bind("Fear", "FleeSeconds", 5.0f, "Сколько секунд он убегает");
            FleeCooldown = Config.Bind("Fear", "FleeCooldown", 8.0f, "Пауза между побегами одного волчонка, сек");

            OffendedEnabled = Config.Bind("Offended", "Enabled", true,
                "Ударенный волчонок сразу перестаёт проситься на ручки (нужен Uppies Please; без него ничего не делает)");
            OffendedCooldown = Config.Bind("Offended", "UppiesCooldownSeconds", 180.0f,
                "Через сколько секунд он снова сможет попроситься на ручки");
            OffendedIcon = Config.Bind("Offended", "Icon", "Sad",
                "Значок над головой: Sad, Angry, Surprise, Chastened (из Uppies Please)");
            OffendedIconSeconds = Config.Bind("Offended", "IconSeconds", 6.0f, "Сколько секунд показывать значок");
            OffendedSounds = Config.Bind("Offended", "Sounds", "WOOF",
                "Звуковые группы обиженного голоса по приоритету (играется вторым, после звука боли)");
            OffendedSoundDelay = Config.Bind("Offended", "SoundDelay", 0.9f, "Через сколько секунд после удара обиженный голос");

            NoGameOver = Config.Bind("Safety", "NoGameOver", true,
                "Отключить game over от ярости волчицы: сон всегда проходит, застрявшие на 3/3 сохранения загружаются");
            NightlyRageRelief = Config.Bind("Safety", "NightlyRageRelief", 1,
                "На сколько очков падает родная ярость волчицы после каждой ночи (0 = не падает)");

            TrustEnabled = Config.Bind("Trust", "Enabled", true, "У каждого волчонка есть доверие к игроку (0..100)");
            TrustPersist = Config.Bind("Trust", "Persist", true, "Сохранять доверие и характеры в файл рядом с конфигом (по имени сохранения)");
            TrustStart = Config.Bind("Trust", "Start", 50.0f, "Начальное доверие");
            TrustLossPerHit = Config.Bind("Trust", "LossPerHit", 15.0f, "Сколько доверия теряет волчонок за удар (с поправкой на характер)");
            TrustGainPerSecondCarried = Config.Bind("Trust", "GainPerSecondCarried", 0.6f, "Прирост доверия в секунду, пока волчонок на руках");
            TrustRegenPerSecond = Config.Bind("Trust", "RegenPerSecond", 0.03f, "Медленное восстановление доверия до начального значения");
            TemperamentEnabled = Config.Bind("Temperament", "Enabled", true, "Волчата получают характер: храбрый, обычный или трусливый");
            BravePercent = Config.Bind("Temperament", "BravePercent", 20, "Процент храбрых");
            TimidPercent = Config.Bind("Temperament", "TimidPercent", 20, "Процент трусливых (остальные обычные)");

            PupHitsPerTemper = Config.Bind("Mama", "PupHitsPerTemper", 2,
                "Сколько ударов по волчатам повышают нрав волчицы на 1 (0 = удары по волчатам нрав не повышают)");
            RevengeEnabled = Config.Bind("Revenge", "Enabled", true, "Разозлённая волчица кусает игрока");
            RevengeMinTemper = Config.Bind("Revenge", "MinTemper", 2, "С какого нрава волчица может укусить");
            RevengeDamage = Config.Bind("Revenge", "Damage", 1, "Сколько здоровья игрока снимает укус");
            RevengeNonLethal = Config.Bind("Revenge", "NonLethal", true, "true = укус не опускает здоровье игрока до нуля (нокаута не будет)");
            RevengeRange = Config.Bind("Revenge", "Range", 7.0f, "Укусить она может, только если игрок ближе этого расстояния");
            RevengeCooldown = Config.Bind("Revenge", "Cooldown", 25.0f, "Пауза между укусами, сек");
            RevengeReleaseTemper = Config.Bind("Revenge", "ReleaseTemper", 1, "На сколько падает нрав после укуса (выпустила пар)");
            PlayerRegenSeconds = Config.Bind("Revenge", "PlayerRegenSeconds", 45.0f, "Через сколько секунд возвращается 1 здоровья, отнятое укусом");

            RaidEnabled = Config.Bind("Raids", "Enabled", true, "Ночные налёты кабанов");
            RaidTemplate = Config.Bind("Raids", "Template", "boar", "Часть названия шаблона налётчика");
            RaidBaseChance = Config.Bind("Raids", "BaseChance", 0.15f, "Базовый шанс налёта за вечер (0..1)");
            RaidPerWounded = Config.Bind("Raids", "PerWoundedPup", 0.12f, "Прибавка к шансу за каждого раненого волчонка");
            RaidMaxChance = Config.Bind("Raids", "MaxChance", 0.8f, "Потолок шанса");
            RaidCount = Config.Bind("Raids", "Count", 1, "Сколько налётчиков появляется");
            RaidDistance = Config.Bind("Raids", "Distance", 32.0f, "Расстояние от волчицы, на котором они появляются");
            RaidNightStartHour = Config.Bind("Raids", "NightStartHour", 18.0f, "С какого времени суток (часы) начинается вечер");
            FryEnabled = Config.Bind("Cauldron", "FryPups", true, "Волчонок, влетевший в горячий котёл, мгновенно погибает вместо того, чтобы париться");
            FryOnlyThrown = Config.Bind("Cauldron", "OnlyThrown", true, "Только если его только что бросил или выпустил игрок");
            FryWindowSeconds = Config.Bind("Cauldron", "ThrownWindowSeconds", 6.0f, "Сколько секунд после броска контакт с котлом считается броском");
            FryDamage = Config.Bind("Cauldron", "Damage", 200, "Урон кипятка");
            FuryDuration = Config.Bind("Fury", "Seconds", 45.0f, "Сколько длится бешенство волчицы");
            FuryBiteCooldown = Config.Bind("Fury", "BiteCooldown", 6.0f, "Как часто в бешенстве она рычит и кусает");
            FuryTrustLoss = Config.Bind("Fury", "TrustLossForPups", 20.0f, "Сколько доверия теряют все волчата");
            SeekMamaChance = Config.Bind("Care", "SeekMamaChance", 0.6f,
                "Шанс, что ударенный волчонок побежит к волчице за утешением (меняется от характера, доверия и черт Pup Traits)");
            SeekMamaSeconds = Config.Bind("Care", "SeekMamaSeconds", 20.0f, "Сколько секунд он ищет волчицу");
            SeekMamaDelay = Config.Bind("Care", "SeekMamaDelaySeconds", 6.0f,
                "Через сколько секунд после удара волчонок побежит к маме (пока он стоит и показывает значок грусти)");
            ComfortDistance = Config.Bind("Care", "ComfortDistance", 3.5f, "Ближе этого расстояния до волчицы волчонка утешают");
            ComfortHeal = Config.Bind("Care", "ComfortHeal", 2, "Сколько здоровья даёт утешение");
            ComfortTrust = Config.Bind("Care", "ComfortTrust", 6.0f, "Сколько доверия к игроку возвращает утешение");
            NearMamaRegenFactor = Config.Bind("Care", "NearMamaRegenFactor", 0.6f,
                "Рядом с волчицей лечение идёт быстрее: интервал умножается на это число (меньше = быстрее)");
            MomStepInChance = Config.Bind("Mom", "StepInChance", 0.5f,
                "Шанс, что после удара по волчонку волчица выйдет к игроку и отчитает его (сцена Uppies Please)");
            MomStepInCooldown = Config.Bind("Mom", "StepInCooldown", 45.0f, "Пауза между такими выходами, сек");
            MomStepInDelay = Config.Bind("Mom", "StepInDelaySeconds", 8.0f, "Через сколько секунд после удара мама выходит к игроку");
            GuardEnabled = Config.Bind("Guard", "Enabled", true,
                "Волчица рычит, если игрок с топором или лопатой подходит к раненому или напуганному волчонку");
            GuardRadius = Config.Bind("Guard", "Radius", 6.0f, "На каком расстоянии от такого волчонка она реагирует");
            GuardCooldown = Config.Bind("Guard", "Cooldown", 25.0f, "Пауза между предупреждениями, сек");
            WanderCompat = Config.Bind("Compat", "PupsWander", true, "Раненые и напуганные волчата не отпускаются бродить (мод Pups Wander)");
            ViolentBiteBack = Config.Bind("Compat", "ViolentPupsBiteBack", true, "Волчонок с чертой Violent (Pup Traits) может укусить игрока в ответ");
            PupBiteCooldown = Config.Bind("Compat", "PupBiteCooldown", 20.0f, "Пауза между укусами волчат, сек");
            LinkMods = Config.Bind("Compat", "LinkMods", true,
                "Общий выключатель связей с другими модами (Uppies Please, Pup Traits, Pups Wander). " +
                "Если что-то в других модах ведёт себя странно, поставь false и проверь, исчезла ли проблема");
            UsePupTraits = Config.Bind("Compat", "UsePupTraits", true,
                "Если установлен Pup Traits, характер волчонка берётся из его черт: Brave -> храбрый, Shy/Scared -> трусливый");
            Verbose = Config.Bind("Debug", "Verbose", false,
                "Писать в лог и частые события (удары, звуки, лечение, страх). Без этого лог в разы короче");

            MamaHpEnabled = Config.Bind("MamaHp", "Enabled", true,
                "У волчицы есть здоровье: удары топора и лопаты его отнимают. При нуле: бешенство (или смерть, если включено MamaCanDie)");
            MamaMaxHp = Config.Bind("MamaHp", "MaxHp", 20, "Здоровье волчицы");
            MamaDamageMul = Config.Bind("MamaHp", "ToolDamageMultiplier", 1.0f, "Множитель урона инструментов по волчице (урон берётся из [Damage])");
            MamaRegenSeconds = Config.Bind("MamaHp", "RegenSeconds", 20.0f, "Секунд на 1 здоровья");
            MamaHealOnSleep = Config.Bind("MamaHp", "HealOnSleep", 10, "Сколько здоровья она восстанавливает за ночь");
            HpAfterFuryFraction = Config.Bind("MamaHp", "HpAfterFury", 0.3f, "Доля здоровья после бешенства, начавшегося от нуля здоровья");
            MamaCanDie = Config.Bind("MamaDeath", "CanDie", false,
                "ОПАСНО. true = смертельный удар по волчице убирает её из семьи навсегда (сохранение остаётся без неё). false = она бессмертна и впадает в бешенство");
            MamaDeathMode = Config.Bind("MamaDeath", "Mode", "Remains",
                "Что происходит с телом: Remains = остаётся мясом на месте гибели (из него варится суп в котле); WalkAway = уходит в лес и скрывается");
            RemainsMeatCount = Config.Bind("MamaDeath", "RemainsMeatCount", 12, "Сколько кусков мяса остаётся при режиме Remains");
            OrphanLeaveChance = Config.Bind("MamaDeath", "OrphanLeaveChance", 0.15f, "Шанс, что волчонок уйдёт из семьи совсем при её смерти (трусливые чаще, храбрые реже)");
            OrphanFeralChance = Config.Bind("MamaDeath", "OrphanFeralChance", 0.35f, "Шанс, что волчонок одичает (станет бродячим) при её смерти");
            OrphanTrustLoss = Config.Bind("MamaDeath", "OrphanTrustLoss", 40.0f, "Сколько доверия теряют все волчата");
            OrphanLeaveDelay = Config.Bind("MamaDeath", "OrphanLeaveDelaySeconds", 25.0f, "Через сколько секунд после смерти уходящий волчонок исчезает (пока он убегает)");
            MamaWalkAwayDistance = Config.Bind("MamaDeath", "WalkAwayDistance", 140.0f, "Как далеко уходит волчица перед тем, как исчезнуть");
            MamaHideDistance = Config.Bind("MamaDeath", "HideDistance", 60.0f, "На каком расстоянии от игрока её скрывают");
            RaidAbsentBonus = Config.Bind("MamaDeath", "RaidChanceBonus", 0.25f, "Прибавка к шансу налёта кабанов, пока волчицы нет (защитить некому)");

            RoarMinInterval = Config.Bind("Mama", "RoarMinIntervalSeconds", 40.0f,
                "Не чаще одного рыка в N секунд (кроме бешенства). Рык ещё и зовёт всех волчат к маме, отсюда спам \"мама!\"");
            IntimidateEnabled = Config.Bind("Intimidate", "Enabled", true, "Игрок может запугать волчицу, и она притихнет");
            IntimidateKey = Config.Bind("Intimidate", "Key", Key.H, "Клавиша: с топором или лопатой, наведясь на волчицу, напугать её");
            IntimidateRange = Config.Bind("Intimidate", "Range", 6.0f, "Дальность угрозы");
            CowedSeconds = Config.Bind("Intimidate", "Seconds", 300.0f, "На сколько секунд она притихает: не рычит, не кусает, не злится");
            IntimidateHits = Config.Bind("Intimidate", "HitsToIntimidate", 3, "Сколько ударов по ней подряд пугают её без клавиши");
            IntimidateWindow = Config.Bind("Intimidate", "HitsWindowSeconds", 15.0f, "За сколько секунд должны прийти эти удары");
            LimitGreetings = Config.Bind("Speech", "LimitGreetings", true, "Ограничить частоту голосов волчат \"мама!\" и \"папа!\"");
            MamaGreetingMinSeconds = Config.Bind("Speech", "MamaGreetingMinSeconds", 25.0f, "Не чаще одного \"мама!\" в N секунд (по всей семье)");
            PlayerGreetingMinSeconds = Config.Bind("Speech", "PlayerGreetingMinSeconds", 12.0f, "Не чаще одного \"папа!\" в N секунд (по всей семье)");
            RedMenaceWrath = Config.Bind("Compat", "RedMenaceWrath", "Off",
                "Месть волчицы из Red Menace (телепорт к игроку, нокаут, game over): Off = никогда; Ours = только за волчат, погибших от нашего мода; Vanilla = не трогать");

            ShooEnabled = Config.Bind("Shoo", "Enabled", true, "Клавиша 'прогнать': волчонок убегает, волчица недовольно рычит");
            ShooKey = Config.Bind("Shoo", "Key", Key.G, "Клавиша 'прогнать'");
            ShooReach = Config.Bind("Shoo", "Reach", 5.0f, "Дальность 'прогнать'");
            ShooRadius = Config.Bind("Shoo", "Radius", 1.2f, "Ширина 'прогнать'");
            ShooTrustLoss = Config.Bind("Shoo", "TrustLoss", 12.0f, "Сколько доверия теряет прогнанный волчонок");
            RunawayAfterShoos = Config.Bind("Shoo", "RunawayAfterShoos", 3,
                "После скольких 'прогнать' подряд волчонок уходит из семьи и становится бродячим (0 = никогда)");

            StraysEnabled = Config.Bind("Strays", "Enabled", true,
                "Если вся семья истреблена, по лесу начинают бродить чужие щенки, которые могут подружиться");
            StrayCount = Config.Bind("Strays", "Count", 2, "Сколько бродячих щенков появляется");
            StrayDelaySeconds = Config.Bind("Strays", "DelaySeconds", 90.0f, "Через сколько секунд после подтверждения истребления они появляются");
            StrayDistance = Config.Bind("Strays", "Distance", 45.0f, "Расстояние от волчицы, на котором они появляются");
            FeralFleeRadius = Config.Bind("Strays", "FleeRadius", 9.0f, "Ближе этого расстояния бродячий щенок убегает от игрока");
            FeralFleeSeconds = Config.Bind("Strays", "FleeSeconds", 6.0f, "Сколько секунд он убегает");
            BefriendRadius = Config.Bind("Strays", "BefriendRadius", 5.0f, "Стоя смирно и без топора/лопаты ближе этого расстояния, ты завоёвываешь доверие");
            BefriendTrustPerSecond = Config.Bind("Strays", "BefriendTrustPerSecond", 1.5f, "Прирост доверия в секунду (на руках вдвое быстрее)");
            BefriendTrust = Config.Bind("Strays", "BefriendTrust", 50.0f, "При каком доверии бродячий щенок принимает вас и возвращается в семью");

            FallsEnabled = Config.Bind("Falls", "Enabled", true, "Реалистичные падения: слабее бросок и урон при приземлении");
            PupThrowSpeedMultiplier = Config.Bind("Falls", "PupThrowSpeedMultiplier", 0.65f,
                "Во сколько раз слабее бросок волчонка (дальность падает примерно как квадрат: 0.65 даёт ~0.42 прежней дальности)");
            SafeFallSpeed = Config.Bind("Falls", "SafeFallSpeed", 8.0f, "Скорость приземления (м/с), до которой падение безопасно");
            DamagePerSpeed = Config.Bind("Falls", "DamagePerSpeed", 1.0f, "Урон за каждый м/с сверх безопасной скорости");
            SafeFallHeight = Config.Bind("Falls", "SafeFallHeight", 3.0f, "Высота падения (м), до которой оно безопасно");
            DamagePerMeter = Config.Bind("Falls", "DamagePerMeter", 1.5f, "Урон за каждый метр высоты сверх безопасной (берётся большее из двух значений)");
            MaxFlightSeconds = Config.Bind("Falls", "MaxFlightSeconds", 6.0f, "Сколько секунд следим за полётом после броска");
            ToastsEnabled = Config.Bind("Debug", "ScreenMessages", true, "Короткие сообщения на экране (укус, налёт)");

            EnableFreeSwing = Config.Bind("FreeSwing", "Enabled", true, "Клавиша удара топором/лопатой без дерева");
            AttackKey = Config.Bind("FreeSwing", "Key", Key.V, "Клавиша свободного удара");
            FreeSwingReach = Config.Bind("FreeSwing", "Reach", 2.5f, "Дальность свободного удара");
            FreeSwingRadius = Config.Bind("FreeSwing", "Radius", 0.5f, "Ширина свободного удара");
            FreeSwingCooldown = Config.Bind("FreeSwing", "Cooldown", 0.7f, "Перезарядка свободного удара, сек");

            DebugLog = Config.Bind("Debug", "DebugLog", true, "Подробный лог попаданий, звуков и ярости");

            new Harmony("local.familytime.friendlyfire").PatchAll(typeof(Plugin).Assembly);
            Log.LogInfo("Friendly Fire 0.13.0 загружен");
        }

        private void Update()
        {
            Combat.TickTemper();
            Combat.TickPlayerRegen();
            Injury.Tick();
            Pups.Tick();
            Raid.Tick();
            Falls.Tick();
            Strays.Tick();
            Shoo.Tick();

            var kbI = Keyboard.current;
            if (IntimidateEnabled.Value && kbI != null && kbI[IntimidateKey.Value].wasPressedThisFrame) Combat.TryIntimidate();

            var kbReset = Keyboard.current;
            if (kbReset != null && kbReset[ResetRageKey.Value].wasPressedThisFrame) Combat.ResetRage();

            if (!EnableFreeSwing.Value) return;
            var kb = Keyboard.current;
            if (kb == null || !kb[AttackKey.Value].wasPressedThisFrame) return;
            if (Time.time < _nextSwing) return;
            if (Cursor.lockState != CursorLockMode.Locked) return; // не во время меню

            var world = World.Instance;
            if (world == null) return;
            var pc = World.playerController;
            if (pc == null || pc.CurrentTool == null) return;

            int dmg;
            float radius = FreeSwingRadius.Value;
            switch (pc.CurrentTool.toolEnum)
            {
                case Tool.ToolEnum.AXE: dmg = AxeDamage.Value; break;
                case Tool.ToolEnum.SHOVEL: dmg = ShovelDamage.Value; break;
                default: return;
            }

            var hand = PlayerController.hand;
            if (hand == null || hand.Camera == null) return;
            _nextSwing = Time.time + FreeSwingCooldown.Value;

            Transform cam = hand.Camera.transform;
            Combat.BeamHit(cam.position, cam.position + cam.forward * FreeSwingReach.Value, radius, dmg, "free swing");
        }

        internal IEnumerator DelayedBeam(Vector3 point, float delay, float radius, int dmg, string src)
        {
            yield return new WaitForSeconds(delay);
            var cam = Combat.GetCameraPos();
            if (cam.HasValue) Combat.BeamHit(cam.Value, point, radius, dmg, src);
        }

        private string _toast;
        private float _toastUntil;

        internal void Toast(string text, float seconds)
        {
            if (!ToastsEnabled.Value) return;
            _toast = text;
            _toastUntil = Time.unscaledTime + seconds;
        }

        private void OnGUI()
        {
            if (string.IsNullOrEmpty(_toast) || Time.unscaledTime > _toastUntil) return;
            var rect = new Rect(0f, Screen.height * 0.12f, Screen.width, 48f);
            // Базовый overload без GUIStyle/TextAnchor: в сборках Unity 6 они вынесены в другие модули.
            GUI.color = Color.white;
            GUI.Label(rect, _toast);
        }

        private void OnApplicationQuit()
        {
            try { Pups.Save(); } catch (Exception e) { Log.LogWarning("save on quit: " + e.Message); }
        }

        internal IEnumerator MomLater(float delay)
        {
            yield return new WaitForSeconds(delay);
            Combat.DoMomStep();
        }

        internal IEnumerator PupLeaves(Handle h, float delay)
        {
            var huddle = World.gatFleeHuddleBehavior;
            if (huddle != null) huddle.Add(h, true, delay + 5f); // убегает
            yield return new WaitForSeconds(delay);
            if (World.gat == null || World.gatUtilities == null || !World.gat.IsHandleValid(h)) yield break;
            var m = World.gat.GetInstanceMatrixImmediate(h);
            Vector3 pos = m.HasValue ? m.Value.GetPosition() : Vector3.zero;
            Combat.MarkOurKill(h);
            World.gatUtilities.KillInstance(h, pos, null, null); // у волчат нет дропа: исчезает тихо
            Log.LogInfo("[fate] pup " + h.stableIndex + " left the family for good");
        }

        internal IEnumerator MomWatchdog(float seconds)
        {
            yield return new WaitForSeconds(seconds);
            UppiesBridge.EndMomIfStuck();
        }

        internal IEnumerator RevengeLater(float delay)
        {
            yield return new WaitForSeconds(delay);
            Combat.TryRevenge();
        }

        internal IEnumerator OffendedSoundLater(Handle h, float delay)
        {
            yield return new WaitForSeconds(delay);
            Injury.PlayOffendedSound(h);
        }

        internal IEnumerator CalmAngryLater(WolfMama mama, float delay)
        {
            yield return new WaitForSeconds(delay);
            if (mama != null) mama.SetAngry(mama.RagePoints > 0);
        }

        internal IEnumerator ClearTrackedLater(WolfMamaAnimalBehavior beh, float delay)
        {
            yield return new WaitForSeconds(delay);
            if (beh == null) yield break;
            var t = Traverse.Create(beh);
            if (!t.Field("_trackedAttacker").GetValue<Handle>().isNull) yield break; // там уже настоящий зверь
            t.Method("ClearTrackedAttacker").GetValue();
        }
    }

    // Поиск типа без AccessTools.TypeByName: тот перебирает типы ВСЕХ сборок и сыплет
    // предупреждениями о сломанных (Unity.VisualEffectGraph / Unity.Timeline).
    internal static class Util
    {
        private static readonly Dictionary<string, Type> Cache = new Dictionary<string, Type>();

        public static Type FindType(string fullName)
        {
            Type t;
            if (Cache.TryGetValue(fullName, out t)) return t;
            foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                try { t = asm.GetType(fullName, false); }
                catch (Exception) { t = null; }
                if (t != null) break;
            }
            Cache[fullName] = t;
            return t;
        }
    }

    // ---------------------------------------------------------------------
    // Хуки
    // ---------------------------------------------------------------------

    // Один вызов = один взмах цикла рубки (вместе с ним игра играет звук удара).
    [HarmonyPatch(typeof(AxeTool), "AnimateChopCrosshairPhase")]
    internal static class AxeChopPatch
    {
        private static void Postfix(AxeTool __instance)
        {
            try
            {
                Vector3 chopPos = Traverse.Create(__instance)
                    .Field("_currentTreeTarget").Field("closestChopPos").GetValue<Vector3>();
                if (chopPos == Vector3.zero) return;

                float delay = Plugin.AxeHitDelay.Value;
                if (delay > 0f)
                {
                    Plugin.Instance.StartCoroutine(Plugin.Instance.DelayedBeam(
                        chopPos, delay, Plugin.AxeBeamRadius.Value, Plugin.AxeDamage.Value, "axe chop"));
                    return;
                }
                var cam = Combat.GetCameraPos();
                if (cam.HasValue)
                    Combat.BeamHit(cam.Value, chopPos, Plugin.AxeBeamRadius.Value, Plugin.AxeDamage.Value, "axe chop");
            }
            catch (Exception e) { Plugin.Log.LogError(e); }
        }
    }

    // actionPos - мировая позиция копания (имя параметра берётся из оригинального метода).
    [HarmonyPatch(typeof(ShovelTool), "QueueShovelAction")]
    internal static class ShovelPatch
    {
        private static void Postfix(Vector3 actionPos)
        {
            try
            {
                var cam = Combat.GetCameraPos();
                if (cam.HasValue)
                    Combat.BeamHit(cam.Value, actionPos, Plugin.ShovelBeamRadius.Value, Plugin.ShovelDamage.Value, "shovel dig");
            }
            catch (Exception e) { Plugin.Log.LogError(e); }
        }
    }

    // Бросок: внутри UseHandPrimary игра задаёт скорость через GAT.SetInstanceVelocity. Помечаем этот момент...
    [HarmonyPatch(typeof(HandService), "UseHandPrimary")]
    internal static class ThrowScopePatch
    {
        private static void Prefix() { Falls.InThrow = true; }
        private static void Finalizer() { Falls.InThrow = false; }
    }

    // ...и ослабляем бросок волчат (предметы и прочее не трогаем).
    [HarmonyPatch]
    internal static class ThrowSpeedPatch
    {
        private static MethodBase TargetMethod()
        {
            var t = Util.FindType("GAT.GAT");
            return t == null ? null : AccessTools.Method(t, "SetInstanceVelocity");
        }

        private static bool Prepare() { return TargetMethod() != null; }

        private static void Prefix(Handle __0, ref Vector3 __1)
        {
            try
            {
                if (!Falls.InThrow || !Plugin.FallsEnabled.Value) return;
                float mul = Plugin.PupThrowSpeedMultiplier.Value;
                if (Mathf.Approximately(mul, 1f)) return;

                var world = World.Instance;
                if (world == null || World.gat == null) return;
                var tmpl = World.gat.GetTemplateFromHandle(__0);
                if (tmpl == null || tmpl.faction == Faction.ITEM) return;

                __1 *= mul;
                if (Plugin.Verbose.Value)
                    Plugin.Log.LogInfo("[throw] pup throw weakened x" + mul.ToString("F2") + " -> " + __1.magnitude.ToString("F1") + " m/s");
            }
            catch (Exception e) { Plugin.Log.LogError(e); }
        }
    }

    // Волчонок влетел в горячий котёл: игра ставит его в очередь "париться" (анимация HOT_WATER).
    // Вместо этого он гибнет, а волчица впадает в бешенство.
    [HarmonyPatch(typeof(CauldronLogicManager), "QueueCommandTemplateHandle")]
    internal static class CauldronFryPatch
    {
        private static void Postfix(CauldronLogicManager __instance, Handle __1)
        {
            try { Cauldron.OnQueued(__instance, __1); }
            catch (Exception e) { Plugin.Log.LogError(e); }
        }
    }

    // Pups Wander: раненые и напуганные волчата не отправляются в НОВОЕ приключение.
    // Eligible() у Pups Wander используется и в основном цикле (там неподходящих волчат он выпускает
    // из-под управления, и мама перестаёт их звать назад), поэтому подменяем его только внутри
    // MaybeStartCuriousAdventure.
    [HarmonyPatch]
    internal static class WanderStartScopePatch
    {
        [ThreadStatic] internal static bool InStart;

        private static MethodBase TargetMethod()
        {
            var t = Util.FindType("FamilyTimeMods.PupsWander.PupsWander");
            return t == null ? null : AccessTools.Method(t, "MaybeStartCuriousAdventure");
        }

        private static bool Prepare() { return TargetMethod() != null; }

        private static void Prefix() { InStart = true; }
        private static void Finalizer() { InStart = false; }
    }

    [HarmonyPatch]
    internal static class WanderEligiblePatch
    {
        private static MethodBase TargetMethod()
        {
            var t = Util.FindType("FamilyTimeMods.PupsWander.PupsWander");
            return t == null ? null : AccessTools.Method(t, "Eligible", new Type[] { typeof(Handle) });
        }

        private static bool Prepare() { return TargetMethod() != null; }

        private static void Postfix(Handle __0, ref bool __result)
        {
            if (__result && WanderStartScopePatch.InStart && Plugin.LinkMods.Value && Plugin.WanderCompat.Value &&
                Injury.IsHurtOrAfraid(__0)) __result = false;
        }
    }

    // Бродячие щенки не считаются детьми в счётчиках ухода игры (количество детей, "не спят", "голодны"),
    // поэтому не мешают ложиться спать и не копят ярость.
    [HarmonyPatch]
    internal static class CareTotalPatch
    {
        private static MethodBase TargetMethod()
        {
            var t = Util.FindType("GAT.GATStateDisplayUI");
            return t == null ? null : AccessTools.Method(t, "RefreshTotalPlayerCount");
        }

        private static bool Prepare() { return TargetMethod() != null; }

        private static void Postfix(object __instance)
        {
            try
            {
                int n = Pups.FeralCount();
                if (n <= 0) return;
                var f = Traverse.Create(__instance).Field("_totalPlayerCount");
                f.SetValue(Mathf.Max(0, f.GetValue<int>() - n));
            }
            catch (Exception e) { Plugin.Log.LogError(e); }
        }
    }

    [HarmonyPatch]
    internal static class CareHungryPatch
    {
        private static MethodBase TargetMethod()
        {
            var t = Util.FindType("GAT.GATStateDisplayUI");
            return t == null ? null : AccessTools.Method(t, "OnHungryCountChanged");
        }

        private static bool Prepare() { return TargetMethod() != null; }

        private static void Postfix(object __instance)
        {
            try
            {
                int n = Pups.FeralHungryCount();
                if (n <= 0) return;
                var f = Traverse.Create(__instance).Field("_hungryTotal");
                f.SetValue(Mathf.Max(0, f.GetValue<int>() - n));
            }
            catch (Exception e) { Plugin.Log.LogError(e); }
        }
    }

    // Бродячие щенки не выбираются исполнителями команд (следовать, нести и т.д.).
    [HarmonyPatch]
    internal static class FeralCommandPatchA
    {
        private static MethodBase TargetMethod()
        {
            var t = Util.FindType("GAT.CommandOwnershipService");
            return t == null ? null : AccessTools.Method(t, "IsAvailableWorker", new Type[] { typeof(Handle), typeof(Predicate<Handle>) });
        }

        private static bool Prepare() { return TargetMethod() != null; }

        private static void Postfix(Handle __0, ref bool __result)
        {
            if (__result && Pups.IsFeral(__0)) __result = false;
        }
    }

    [HarmonyPatch]
    internal static class FeralCommandPatchB
    {
        private static MethodBase TargetMethod()
        {
            var t = Util.FindType("GAT.CommandOwnershipService");
            return t == null ? null : AccessTools.Method(t, "IsAvailableWorker", new Type[] { typeof(Handle) });
        }

        private static bool Prepare() { return TargetMethod() != null; }

        private static void Postfix(Handle __0, ref bool __result)
        {
            if (__result && Pups.IsFeral(__0)) __result = false;
        }
    }

    // Волчицы нет: игра, Free Roam, Uppies Please и Pups Wander не должны её звать.
    [HarmonyPatch(typeof(WolfMama), "AllowFollow", MethodType.Getter)]
    internal static class MamaAllowFollowPatch
    {
        private static void Postfix(ref bool __result)
        {
            if (MamaFate.Absent) __result = false;
        }
    }

    // Команды движения не должны уводить её обратно (кроме нашей собственной команды "уйти").
    [HarmonyPatch(typeof(GATMoveBehavior), "CommandMove")]
    internal static class MamaMoveBlockPatch
    {
        private static void Prefix(ref Handle[] __0)
        {
            try
            {
                if (!MamaFate.Absent || MamaFate.IssuingOwnMove || __0 == null || __0.Length == 0) return;
                var mama = WolfMama.ActiveInstance;
                if (mama == null) return;
                Handle mh;
                if (!mama.TryGetHandle(out mh)) return;

                var keep = new List<Handle>(__0.Length);
                foreach (Handle h in __0) if (h != mh) keep.Add(h);
                if (keep.Count != __0.Length) __0 = keep.ToArray();
            }
            catch (Exception e) { Plugin.Log.LogError(e); }
        }
    }

    // После нокаута игрока игра телепортирует его к волчице: без неё телепорт пропускаем.
    [HarmonyPatch(typeof(PlayerController), "TeleportToWolfMama")]
    internal static class MamaTeleportPatch
    {
        private static bool Prefix() { return !MamaFate.Absent; }
    }

    // Волчата не реагируют на присутствие волчицы, которой нет.
    [HarmonyPatch]
    internal static class MamaProximityPatch
    {
        private static MethodBase TargetMethod()
        {
            var t = Util.FindType("GAT.GATCharacterProximityBehavior");
            return t == null ? null : AccessTools.Method(t, "TryGetWolfMamaSource");
        }

        private static bool Prepare() { return TargetMethod() != null; }

        private static void Postfix(ref bool __result)
        {
            if (MamaFate.Absent) __result = false;
        }
    }

    // Запуганная волчица не рычит и по велению игры (в том числе зов волчат к себе).
    [HarmonyPatch(typeof(WolfMamaAnimalBehavior), "TryStartRoar")]
    internal static class CowedRoarPatch
    {
        private static bool Prefix() { return !Combat.IsCowed(); }
    }

    // Голоса волчат "мама!" (WOLF_MAMA_PROXIMITY) и "папа!" (PLAYER_PROXIMITY) не чаще раза в N секунд на всю семью.
    [HarmonyPatch]
    internal static class GreetingLimiterPatch
    {
        private static float _lastMama = -999f, _lastPlayer = -999f;

        private static MethodBase TargetMethod()
        {
            var t = Util.FindType("GAT.GATSpeechManager");
            return t == null ? null : AccessTools.Method(t, "PlaySpeech");
        }

        private static bool Prepare() { return TargetMethod() != null; }

        private static bool Prefix(AudioGroupEnum __1)
        {
            if (!Plugin.LimitGreetings.Value) return true;
            float now = Time.unscaledTime;
            if (__1 == AudioGroupEnum.WOLF_MAMA_PROXIMITY)
            {
                if (now - _lastMama < Plugin.MamaGreetingMinSeconds.Value) return false;
                _lastMama = now;
            }
            else if (__1 == AudioGroupEnum.PLAYER_PROXIMITY)
            {
                if (now - _lastPlayer < Plugin.PlayerGreetingMinSeconds.Value) return false;
                _lastPlayer = now;
            }
            return true;
        }
    }

    // Red Menace: за гибель любого волчонка волчица телепортируется за спину игрока, нокаутирует его и
    // вызывает game over. Отключаем это (режим Off) либо только для гибели, вызванной нашим модом (Ours).
    [HarmonyPatch]
    internal static class RedMenaceWrathPatch
    {
        private static bool _logged;

        private static MethodBase TargetMethod()
        {
            var t = Util.FindType("RedMenace.WolfMamaWrathController");
            return t == null ? null : AccessTools.Method(t, "OnInstanceKilled");
        }

        private static bool Prepare() { return TargetMethod() != null; }

        // false = не выполнять оригинал (никакой мести)
        private static bool Prefix(GATUtilities.DeathNotification __0)
        {
            string mode = (Plugin.RedMenaceWrath.Value ?? "Off").Trim().ToLowerInvariant();
            if (mode == "vanilla") return true;
            if (mode == "ours" && !Combat.IsOurKill(__0.handle)) return true;
            if (!_logged)
            {
                _logged = true;
                Plugin.Log.LogInfo("[redmenace] месть волчицы за волчонка отключена (Compat.RedMenaceWrath = " + Plugin.RedMenaceWrath.Value + ")");
            }
            return false;
        }
    }

    // Единственный источник game over в игре - HasTerminalRage (ярость >= 3 при отходе ко сну или при загрузке).
    // Если он всегда false, сон проходит как обычно, а застрявшие на 3/3 сохранения загружаются.
    [HarmonyPatch(typeof(WolfMama), "HasTerminalRage", MethodType.Getter)]
    internal static class NoGameOverPatch
    {
        private static void Postfix(ref bool __result)
        {
            if (Plugin.NoGameOver.Value) __result = false;
        }
    }

    // Утро: после ночи родная ярость волчицы немного отпускает.
    [HarmonyPatch(typeof(BedManager), "BeginSleepFadeFromBlack")]
    internal static class WakePatch
    {
        private static void Postfix()
        {
            try { Combat.OnWake(); }
            catch (Exception e) { Plugin.Log.LogError(e); }
        }
    }

    // Срабатывает, когда игра действительно начинает сон (GameSession.TryBeginSleep вернул true),
    // то есть ДО родной проверки "дети не спят / голодные" и game over в BedManager.BeginSleep.
    [HarmonyPatch]
    internal static class SleepPatch
    {
        private static MethodBase TargetMethod()
        {
            var t = Util.FindType("family.GameSession");
            return t == null ? null : AccessTools.Method(t, "TryBeginSleep");
        }

        private static bool Prepare() { return TargetMethod() != null; }

        private static void Postfix(bool __result)
        {
            try { if (__result) Combat.OnSleepStarting(); }
            catch (Exception e) { Plugin.Log.LogError(e); }
        }
    }

    // ---------------------------------------------------------------------
    // Логика попадания, урона, звуков и волчицы
    // ---------------------------------------------------------------------
    internal static class Combat
    {
        private static readonly Dictionary<ushort, float> LastHit = new Dictionary<ushort, float>();
        private static readonly HashSet<string> LoggedTemplates = new HashSet<string>();

        private static float _lastMamaHit = -999f;

        // "Нрав" волчицы - собственный счётчик мода. Родная ярость игры (счётчик game over)
        // меняется только если к отходу ко сну она ещё злится, либо по клавише сброса.
        private static int _temper;
        private static float _nextCalm;
        private static WolfMama _temperOwner;
        private static int _seenRage = -1;

        // кэш разобранных списков звуковых групп
        private static readonly Dictionary<string, AudioGroupEnum[]> GroupListCache = new Dictionary<string, AudioGroupEnum[]>();

        public static Vector3? GetCameraPos()
        {
            var world = World.Instance;
            if (world == null || World.playerController == null) return null;
            var hand = PlayerController.hand;
            if (hand == null || hand.Camera == null) return null;
            return hand.Camera.transform.position;
        }

        // ---------------- попадание ----------------

        // Позиций существ на CPU нет (всё на GPU), поэтому используем тот же запрос, которым
        // игра находит зверей под прицелом: луч от камеры. Для ширины - 5 параллельных лучей.
        public static void BeamHit(Vector3 origin, Vector3 end, float radius, int damage, string source)
        {
            var world = World.Instance;
            if (world == null) return;

            Vector3 axis = end - origin;
            float dist = axis.magnitude;
            if (dist < 0.05f) return;
            Vector3 dir = axis / dist;

            Vector3 right = Vector3.Cross(Vector3.up, dir);
            if (right.sqrMagnitude < 1e-4f) right = Vector3.right;
            right.Normalize();
            Vector3 up = Vector3.Cross(dir, right).normalized;

            Vector3[] offsets = { Vector3.zero, right * radius, -right * radius, up * radius, -up * radius };
            var seen = new HashSet<ushort>();

            if (Plugin.Verbose.Value)
                Plugin.Log.LogInfo("[swing] " + source + " dist=" + dist.ToString("F2") + " dmg=" + damage);

            foreach (Vector3 off in offsets)
            {
                World.RaycastGATInstances(origin + off, dir, dist + 0.3f,
                    cands => OnCandidates(cands, seen, damage, source));
            }

            if (Plugin.HitMama.Value) TryHitMama(origin, end, radius, source, damage);
        }

        private static void OnCandidates(World.GATInstanceRaycastCandidate[] cands, HashSet<ushort> seen, int damage, string source)
        {
            if (cands == null) return;
            var world = World.Instance;
            if (world == null) return;
            var hand = World.playerController != null ? PlayerController.hand : null;

            foreach (var c in cands)
            {
                if (!c.IsValid) continue;
                Handle h = c.Handle;
                if (!seen.Add(h.stableIndex)) continue;
                if (!FactionAllowed(c.Faction)) continue;
                if (!Plugin.HitCarried.Value && hand != null && hand.IsCarryingGAT(h)) continue;
                if (OnCooldown(h.stableIndex)) continue;

                if (Plugin.Verbose.Value)
                    Plugin.Log.LogInfo("[hit] " + source + " -> handle " + h.stableIndex + " faction=" + c.Faction);

                Damage(h, c.candidateHeadPos, damage, 0, c.Faction == Faction.PLAYER);
            }
        }

        private static bool FactionAllowed(Faction f)
        {
            switch (f)
            {
                case Faction.PLAYER: return Plugin.HitPlayerFaction.Value;
                case Faction.PASSIVE: return Plugin.HitPassive.Value;
                case Faction.HOSTILE: return Plugin.HitHostile.Value;
                default: return false; // ITEM и UNUSED_* не трогаем
            }
        }

        private static bool OnCooldown(ushort id)
        {
            float now = Time.time, last;
            if (LastHit.TryGetValue(id, out last) && now - last < Plugin.HitCooldown.Value) return true;
            LastHit[id] = now;
            return false;
        }

        // ---------------- урон ----------------

        // Урон волчонку от падения (игрок виноват: срабатывают звук, обида, потеря доверия и т.д.).
        internal static void HurtFromFall(Handle h, Vector3 pos, int dmg)
        {
            Damage(h, pos, dmg, 0, true);
        }

        // Тот же вызов, которым игра наносит урон от атак волков.
        // attempt 0: источник = сама цель. Если шейдер отказал (effectiveDelta == 0),
        // attempt 1: источник = волчица.
        private static void Damage(Handle target, Vector3 pos, int damage, int attempt, bool family)
        {
            var world = World.Instance;
            if (world == null || World.gatUtilities == null) return;
            var gat = World.gat;
            if (gat == null || !gat.IsHandleValid(target)) return;

            Handle source = target;
            if (attempt == 1)
            {
                var mama = WolfMama.ActiveInstance;
                if (mama == null) return;
                source = mama.FakeGATHandle;
            }

            short delta = (short)(-Mathf.Abs(damage));
            World.gatUtilities.ApplyHealthDelta(pos, source, target, delta, 100f,
                res => OnResult(res, target, pos, damage, attempt, family));
        }

        // Повторяет то, что игра делает в Autonomy.OnAttackEvent, плюс голос и защита волчицы.
        private static void OnResult(GATUtilities.InfoDeltaResult res, Handle target, Vector3 pos, int damage, int attempt, bool family)
        {
            var world = World.Instance;
            if (world == null) return;

            if (Plugin.Verbose.Value)
                Plugin.Log.LogInfo("[dmg] handle=" + target.stableIndex + " attempt=" + attempt +
                    " ok=" + res.requestSucceeded + " effective=" + res.effectiveDelta + " hp=" + res.currentValue);

            if (res.effectiveDelta >= 0)
            {
                if (attempt == 0) Damage(target, pos, damage, 1, family);
                return;
            }

            var gat = World.gat;
            if (gat == null) return;

            // голос - до возможного удаления инстанса
            try { PlayHurtSound(target, res.headPos); }
            catch (Exception e) { Plugin.Log.LogWarning("hurt sound: " + e.Message); }

            // иногда волчица рычит на игрока (и игра зовёт свободных волчат к ней)
            if (family && UnityEngine.Random.value < Plugin.RoarChance.Value)
            {
                var cam = GetCameraPos();
                if (cam.HasValue) MamaRoarAt(cam.Value);
            }

            if (res.currentValue == 0)
            {
                var killedTmpl = gat.GetTemplateFromHandle(target); // до удаления инстанса
                bool alreadyDropsMeat = HasAnyDrop(killedTmpl);

                MarkOurKill(target);
                World.gatUtilities.KillInstance(target, res.headPos, null, null);

                if (Plugin.MeatEnabled.Value && !alreadyDropsMeat &&
                    (family ? Plugin.MeatFromFamily.Value : Plugin.MeatFromOthers.Value))
                    DropMeat(res.headPos);

                if (Plugin.ShockEnabled.Value && (family || Plugin.ShockOnAnyKill.Value))
                    Shock();
                return;
            }

            if (family)
            {
                try { OnPupHurtByPlayer(); Injury.OnHurt(target); MomStepsIn(); }
                catch (Exception e) { Plugin.Log.LogWarning("injury: " + e.Message); }
            }

            try
            {
                var tmpl = gat.GetTemplateFromHandle(target);
                var anim = World.gatAnimationManager;
                if (anim != null)
                    anim.PlayAnimations(new[] { target }, AnimationEnum.PAIN, 0, true, null, tmpl, false);

                var autonomy = Util.FindType("GAT.Autonomy");
                var m = autonomy != null ? AccessTools.Method(autonomy, "ShouldFleeWhenAttacked") : null;
                bool flee = m != null && (bool)m.Invoke(null, new object[] { gat.ResolveHandle(target) });
                if (flee && World.gatRunRandomlyBehavior != null)
                    World.gatRunRandomlyBehavior.Add(new[] { target });
            }
            catch (Exception e) { Plugin.Log.LogWarning(e.Message); }
        }

        // ---------------- голос раненого ----------------

        internal static AudioGroupEnum[] ParseGroups(string src)
        {
            src = src ?? "";
            AudioGroupEnum[] arr;
            if (GroupListCache.TryGetValue(src, out arr)) return arr;
            var list = new List<AudioGroupEnum>();
            foreach (string raw in src.Split(','))
            {
                AudioGroupEnum g;
                if (Enum.TryParse<AudioGroupEnum>(raw.Trim(), true, out g)) list.Add(g);
            }
            arr = list.ToArray();
            GroupListCache[src] = arr;
            return arr;
        }

        internal static void PlayHurtSound(Handle target, Vector3 pos)
        {
            if (!Plugin.HurtSoundEnabled.Value) return;
            PlaySoundFromList(target, pos, ParseGroups(Plugin.HurtSounds.Value));
        }

        // Берём звуковую группу из шаблона существа и играем её тем же путём, что и игра
        // (GATSpeechManager.PlaySpeech): со звуком в позиции и анимацией рта.
        internal static void PlaySoundFromList(Handle target, Vector3 pos, AudioGroupEnum[] groups)
        {
            var world = World.Instance;
            if (world == null) return;
            var gat = World.gat;
            var speech = World.speechManager;
            if (gat == null || speech == null) return;

            ushort phys = gat.ResolveHandle(target);
            if (phys == 65535) return;
            var tmpl = gat.GetTemplateFromHandle(target);
            if (tmpl == null) return;

            if (Plugin.DebugLog.Value && LoggedTemplates.Add(tmpl.name))
            {
                var have = new List<string>();
                foreach (AudioGroupEnum g in Enum.GetValues(typeof(AudioGroupEnum)))
                    if (tmpl.GetAudioGroup(g) != null) have.Add(g.ToString());
                Plugin.Log.LogInfo("[snd] template '" + tmpl.name + "' has audio groups: " +
                    (have.Count > 0 ? string.Join(", ", have.ToArray()) : "(none)"));
            }

            foreach (AudioGroupEnum g in groups)
            {
                if (tmpl.GetAudioGroup(g) == null) continue;
                speech.PlaySpeech(pos, g, phys);
                if (Plugin.Verbose.Value) Plugin.Log.LogInfo("[snd] handle " + target.stableIndex + " -> " + g);
                return;
            }
        }

        // ---------------- волчица: удар, ярость, рык ----------------

        private static void TryHitMama(Vector3 origin, Vector3 end, float radius, string source, int damage)
        {
            var mama = WolfMama.ActiveInstance;
            if (mama == null || MamaFate.Absent) return;

            Vector3 p = mama.transform.position + Vector3.up * 0.9f;
            if (DistPointSegment(p, origin, end) > Plugin.MamaHitRadius.Value + radius) return;

            var hand = World.playerController != null ? PlayerController.hand : null;
            if (!Plugin.HitCarried.Value && hand != null && hand.IsCarryingGAT(mama.FakeGATHandle)) return;

            // урон здоровью: каждый взмах, с короткой паузой (как у остальных целей)
            if (Plugin.MamaHpEnabled.Value && Time.time - _lastMamaDamage >= Plugin.HitCooldown.Value)
            {
                _lastMamaDamage = Time.time;
                DamageMama(mama, damage, source);
                if (MamaFate.Absent) return; // смертельный удар: дальше уже некому рычать
            }

            // несколько ударов подряд пугают её: дальше она не злится и не рычит
            if (Plugin.IntimidateEnabled.Value && RegisterHitForIntimidation()) return;

            // нрав и рык: не чаще, чем раз в MamaCooldown
            if (Time.time - _lastMamaHit < Plugin.MamaCooldown.Value) return;
            _lastMamaHit = Time.time;

            AddTemper(mama, Plugin.MamaRagePerHit.Value);

            if (Plugin.DebugLog.Value)
                Plugin.Log.LogInfo("[mama] " + source + " -> temper " + _temper + "/" + Plugin.MaxTemper.Value +
                    ", -1 in " + Plugin.RageDecaySeconds.Value.ToString("F0") + "s (game rage " + mama.RagePoints + ")");

            if (Plugin.RoarOnMamaHit.Value) MamaRoarAt(origin);
        }

        // Раз в кадр: пора ли волчице успокоиться на одно очко нрава.
        public static void TickTemper()
        {
            WatchRage();
            TickFury();
            TickMamaHp();
            TickCowed();
            MamaFate.Tick();
            if (_temper <= 0) return;
            var mama = WolfMama.ActiveInstance;
            if (mama == null || mama != _temperOwner) { _temper = 0; return; } // загрузка/новая сессия
            if (Time.time < _nextCalm) return;

            _temper--;
            _nextCalm = Time.time + Plugin.RageDecaySeconds.Value;
            if (_temper == 0) mama.SetAngry(mama.RagePoints > 0);

            if (Plugin.DebugLog.Value)
                Plugin.Log.LogInfo("[mama] calmed down: temper " + (_temper + 1) + " -> " + _temper +
                    " (game rage stays " + mama.RagePoints + ")");
        }

        // Игрок действительно ложится спать. Вызывается до родной проверки и game over.
        public static void OnSleepStarting()
        {
            _sleepStarted = true;
            try { Pups.Save(); }
            catch (Exception e) { Plugin.Log.LogWarning("save pups: " + e.Message); }
            try { Injury.OnSleep(); }
            catch (Exception e) { Plugin.Log.LogWarning("heal on sleep: " + e.Message); }

            int t = _temper;
            _temper = 0;
            var mama = WolfMama.ActiveInstance;
            if (mama == null) return;

            if (t > 0 && Plugin.BedtimeAngerAddsRage.Value)
            {
                int before = mama.RagePoints;
                mama.AddRagePoint();
                _seenRage = mama.RagePoints;
                Plugin.Log.LogInfo("[mama] still angry at bedtime (temper " + t + ") -> game rage " + before + " -> " + mama.RagePoints);
            }
            else
            {
                Plugin.Log.LogInfo("[mama] bedtime: temper " + t + ", game rage " + mama.RagePoints + " (мод ничего не добавляет)");
            }
        }

        private static bool _sleepStarted;
        private static int _pupHitCounter;
        private static float _lastRevenge = -999f;
        private static int _biteDebt;
        private static float _nextPlayerRegen;

        // Утро после сна: родная ярость падает на NightlyRageRelief.
        public static void OnWake()
        {
            if (!_sleepStarted) return;
            _sleepStarted = false;

            var m0 = WolfMama.ActiveInstance;
            if (m0 != null && _furyUntil > 0f) EndFury(m0); // утром бешенство проходит
            if (!MamaFate.Absent && _mamaHp >= 0) _mamaHp = Mathf.Min(MamaMax(), _mamaHp + Plugin.MamaHealOnSleep.Value);
            try { MamaFate.OnWake(); } catch (Exception e) { Plugin.Log.LogWarning("fate wake: " + e.Message); }

            int relief = Plugin.NightlyRageRelief.Value;
            var mama = WolfMama.ActiveInstance;
            if (relief <= 0 || mama == null) return;
            int before = mama.RagePoints;
            if (before <= 0) return;

            int to = Mathf.Max(0, before - relief);
            Traverse.Create(mama).Field("ragePoints").SetValue(to); // RestoreRagePoints недоступен (internal)
            _seenRage = mama.RagePoints;
            Plugin.Log.LogInfo("[mama] morning: native rage " + before + " -> " + mama.RagePoints);
        }

        // Удар по волчонку: каждые PupHitsPerTemper ударов нрав волчицы растёт на 1.
        private static void OnPupHurtByPlayer()
        {
            int n = Plugin.PupHitsPerTemper.Value;
            if (n <= 0) return;
            var mama = WolfMama.ActiveInstance;
            if (mama == null || MamaFate.Absent || IsCowed()) return;
            if (++_pupHitCounter < n) return;
            _pupHitCounter = 0;
            AddTemper(mama, 1);
            if (Plugin.DebugLog.Value)
                Plugin.Log.LogInfo("[mama] pups were hit -> temper " + _temper + "/" + Plugin.MaxTemper.Value);
        }

        // Месть: разозлённая волчица кусает игрока, если он рядом.
        public static void TryRevenge()
        {
            try
            {
                if (!Plugin.RevengeEnabled.Value || MamaFate.Absent || IsCowed()) return;
                bool fury = _furyUntil > 0f && Time.time < _furyUntil;
                if (!fury && _temper < Plugin.RevengeMinTemper.Value) return;
                float biteCooldown = fury ? Plugin.FuryBiteCooldown.Value : Plugin.RevengeCooldown.Value;
                if (Time.time - _lastRevenge < biteCooldown) return;

                var mama = WolfMama.ActiveInstance;
                var world = World.Instance;
                if (mama == null || world == null || World.playerController == null) return;
                var cam = GetCameraPos();
                if (!cam.HasValue) return;
                if (Vector3.Distance(mama.transform.position, cam.Value) > Plugin.RevengeRange.Value) return;

                var pc = World.playerController;
                if (pc.IsKnockedOut) return;

                int hp = Traverse.Create(pc).Field("health").GetValue<int>();
                int dmg = Mathf.Max(1, Plugin.RevengeDamage.Value);
                _lastRevenge = Time.time;

                if (Plugin.RevengeNonLethal.Value && hp - dmg <= 0)
                {
                    Plugin.Instance.Toast("Волчица грозно рычит на вас...", 3f);
                    if (Plugin.DebugLog.Value) Plugin.Log.LogInfo("[revenge] growls only (player health " + hp + ")");
                    return;
                }

                pc.OnDamage(dmg);
                _biteDebt += dmg;
                _nextPlayerRegen = Time.time + Plugin.PlayerRegenSeconds.Value;
                if (!fury) // в бешенстве нрав не падает, пока оно не кончится
                {
                    _temper = Mathf.Max(0, _temper - Plugin.RevengeReleaseTemper.Value);
                    if (_temper == 0) mama.SetAngry(mama.RagePoints > 0);
                }

                Plugin.Instance.Toast("Волчица укусила вас!", 3.5f);
                Plugin.Log.LogInfo("[revenge] mama bit the player: health " + hp + " -> " + (hp - dmg) + ", temper now " + _temper);
            }
            catch (Exception e) { Plugin.Log.LogWarning("revenge: " + e.Message); }
        }

        // Здоровье, отнятое укусом, возвращается (родной регенерации у игрока нет).
        public static void TickPlayerRegen()
        {
            if (_biteDebt <= 0 || Time.time < _nextPlayerRegen) return;
            var world = World.Instance;
            if (world == null || World.playerController == null) return;
            var pc = World.playerController;
            if (pc.IsKnockedOut) { _biteDebt = 0; return; }

            var t = Traverse.Create(pc);
            int hp = t.Field("health").GetValue<int>();
            int max = t.Field("MaximumHealth").GetValue<int>();
            if (hp < max) t.Field("health").SetValue(hp + 1);
            _biteDebt--;
            _nextPlayerRegen = Time.time + Plugin.PlayerRegenSeconds.Value;
            if (Plugin.DebugLog.Value) Plugin.Log.LogInfo("[revenge] player health restored: " + Mathf.Min(max, hp + 1) + "/" + max);
        }

        // ---------- бешенство волчицы ----------

        private static float _furyUntil, _nextFuryBite;
        private static int _mamaHp = -1;
        private static float _nextMamaRegen;
        private static float _lastMamaDamage = -999f;
        private static bool _furyDepleted, _lowHpWarned;
        private static WolfMama _hpOwner;

        private static int MamaMax() { return Mathf.Max(1, Plugin.MamaMaxHp.Value); }

        // Удар инструмента по волчице. При нуле: смерть (если разрешена) либо бешенство (бессмертна).
        private static void DamageMama(WolfMama mama, int dmg, string source)
        {
            if (MamaFate.Absent) return;
            if (mama != _hpOwner) { _hpOwner = mama; _mamaHp = MamaMax(); _furyUntil = 0f; }
            if (_mamaHp < 0) _mamaHp = MamaMax();
            if (_furyUntil > 0f) return; // в бешенстве урон не копится

            int d = Mathf.Max(1, Mathf.RoundToInt(dmg * Plugin.MamaDamageMul.Value));
            _mamaHp = Mathf.Max(0, _mamaHp - d);
            _nextMamaRegen = Time.time + Plugin.MamaRegenSeconds.Value;
            if (Plugin.DebugLog.Value)
                Plugin.Log.LogInfo("[mama] " + source + " damage " + d + " -> health " + _mamaHp + "/" + MamaMax());

            if (Plugin.MamaCanDie.Value && !_lowHpWarned && _mamaHp * 10 <= MamaMax() * 3 && _mamaHp > 0)
            {
                _lowHpWarned = true;
                Plugin.Instance.Toast("Волчица тяжело ранена! Следующие удары могут её убить", 5f);
            }

            if (_mamaHp <= 0)
            {
                if (Plugin.MamaCanDie.Value) MamaFate.Die(mama);
                else if (!IsCowed()) StartFury(mama, true);
                else _mamaHp = 1; // запуганная волчица не бесится, а жмётся
            }
        }

        // Раз в кадр: регенерация здоровья волчицы.
        private static void TickMamaHp()
        {
            if (MamaFate.Absent || _furyUntil > 0f) return;
            var mama = WolfMama.ActiveInstance;
            if (mama == null || _mamaHp < 0 || _mamaHp >= MamaMax() || Time.time < _nextMamaRegen) return;
            _mamaHp++;
            _nextMamaRegen = Time.time + Plugin.MamaRegenSeconds.Value;
            if (_mamaHp * 10 > MamaMax() * 5) _lowHpWarned = false;
        }

        // ---------- запугивание и тишина ----------

        private static float _cowedUntil, _lastRoarAt;
        private static readonly List<float> MamaHitTimes = new List<float>();
        private static readonly Dictionary<ushort, float> OurKills = new Dictionary<ushort, float>();

        internal static bool IsCowed() { return Time.time < _cowedUntil; }

        // Волчица запугана: не рычит (ни мы, ни игра), не кусает, не злится.
        internal static void Intimidate(float seconds, string reason)
        {
            var mama = WolfMama.ActiveInstance;
            if (mama == null || MamaFate.Absent) return;
            bool was = IsCowed();
            _cowedUntil = Mathf.Max(_cowedUntil, Time.time + seconds);
            if (_furyUntil > 0f) EndFury(mama);
            _temper = 0;
            mama.SetAngry(false);
            if (!was)
            {
                Plugin.Instance.Toast("Волчица боится вас и притихла", 4f);
                Plugin.Log.LogInfo("[mama] intimidated (" + reason + ") for " + seconds.ToString("F0") + "s");
            }
        }

        private static void TickCowed()
        {
            if (_cowedUntil > 0f && Time.time >= _cowedUntil)
            {
                _cowedUntil = 0f;
                Plugin.Instance.Toast("Волчица осмелела", 3f);
            }
        }

        // Клавиша: с топором или лопатой навестись на волчицу.
        internal static void TryIntimidate()
        {
            if (Cursor.lockState != CursorLockMode.Locked) return;
            var mama = WolfMama.ActiveInstance;
            if (mama == null || MamaFate.Absent) return;

            var pc = World.playerController;
            var tool = pc != null ? pc.CurrentTool : null;
            bool armed = tool != null && (tool.toolEnum == Tool.ToolEnum.AXE || tool.toolEnum == Tool.ToolEnum.SHOVEL);
            if (!armed) { Plugin.Instance.Toast("Чтобы напугать её, возьми топор или лопату", 3f); return; }

            var hand = PlayerController.hand;
            if (hand == null || hand.Camera == null) return;
            Transform cam = hand.Camera.transform;
            Vector3 p = mama.transform.position + Vector3.up * 0.9f;
            Vector3 end = cam.position + cam.forward * Plugin.IntimidateRange.Value;
            if (DistPointSegment(p, cam.position, end) > 1.6f) return; // не на неё смотрит

            Intimidate(Plugin.CowedSeconds.Value, "threat");
        }

        // Удары по волчице подряд тоже пугают её.
        private static bool RegisterHitForIntimidation()
        {
            if (IsCowed()) return true;
            float now = Time.time;
            MamaHitTimes.Add(now);
            MamaHitTimes.RemoveAll(t => now - t > Plugin.IntimidateWindow.Value);
            if (MamaHitTimes.Count >= Mathf.Max(1, Plugin.IntimidateHits.Value))
            {
                MamaHitTimes.Clear();
                Intimidate(Plugin.CowedSeconds.Value, "hits");
                return true;
            }
            return false;
        }

        // Волчонка убили мы (топор, падение, котёл, уход сирот): нужно, чтобы Red Menace не мстил за него.
        internal static void MarkOurKill(Handle h) { OurKills[h.stableIndex] = Time.time; }
        internal static bool IsOurKill(Handle h)
        {
            float t;
            return OurKills.TryGetValue(h.stableIndex, out t) && Time.time - t < 15f;
        }

        // Орфаны вокруг: шок только у волчат (мама уходит, ей не до рыка).
        internal static void ShockPupsOnly()
        {
            if (World.gatUtilities != null)
                World.gatUtilities.GetInstancesByFaction(Faction.PLAYER, list => OnFamilyExtracted(list));
        }

        private static void StartFury(WolfMama mama, bool depleted = false)
        {
            if (MamaFate.Absent || IsCowed()) return;
            if (_furyUntil > 0f)
            {
                _furyUntil = Mathf.Max(_furyUntil, Time.time + Plugin.FuryDuration.Value); // уже бушует: продлить
                return;
            }
            _furyDepleted = depleted;
            _furyUntil = Time.time + Plugin.FuryDuration.Value;
            _nextFuryBite = Time.time;
            _temperOwner = mama;
            _temper = Mathf.Max(1, Plugin.MaxTemper.Value);
            _nextCalm = _furyUntil + Plugin.RageDecaySeconds.Value;
            mama.SetAngry(true);

            Plugin.Instance.Toast("Волчица в бешенстве!", 5f);
            Plugin.Log.LogInfo("[mama] FURY for " + Plugin.FuryDuration.Value.ToString("F0") + "s");
            Pups.OnMamaFury();
        }

        private static void EndFury(WolfMama mama)
        {
            _furyUntil = 0f;
            _temper = 0;
            if (_furyDepleted)
                _mamaHp = Mathf.Max(1, Mathf.RoundToInt(MamaMax() * Plugin.HpAfterFuryFraction.Value));
            _furyDepleted = false;
            _nextMamaRegen = Time.time + Plugin.MamaRegenSeconds.Value;
            mama.SetAngry(mama.RagePoints > 0);
            Plugin.Instance.Toast("Волчица пришла в себя", 4f);
            Plugin.Log.LogInfo("[mama] fury is over");
        }

        // Раз в кадр: в бешенстве она регулярно рычит (рык запускает проверку укуса).
        private static void TickFury()
        {
            if (_furyUntil <= 0f) return;
            var mama = WolfMama.ActiveInstance;
            if (mama == null) { _furyUntil = 0f; return; }
            if (Time.time >= _furyUntil) { EndFury(mama); return; }
            if (Time.time < _nextFuryBite) return;

            _nextFuryBite = Time.time + Plugin.FuryBiteCooldown.Value;
            var cam = GetCameraPos();
            if (cam.HasValue) MamaRoarAt(cam.Value);
        }

        // Котёл: волчонок погиб в кипятке. Волчица в бешенстве (шок остальных запускается самой гибелью).
        internal static void Fry(Handle h, Vector3 pos, int dmg)
        {
            Damage(h, pos, dmg, 0, true);
            var mama = WolfMama.ActiveInstance;
            if (mama != null) StartFury(mama);
        }

        // ---------- мама и дети ----------

        private static float _lastMomStep = -999f;
        private static float _lastPupBite = -999f;

        // После удара по волчонку мама выходит к игроку и отчитывает его: запускаем готовую сцену Uppies Please.
        private static void MomStepsIn()
        {
            if (Plugin.MomStepInChance.Value <= 0f || MamaFate.Absent || IsCowed()) return;
            if (Time.time - _lastMomStep < Plugin.MomStepInCooldown.Value) return;
            if (UnityEngine.Random.value >= Plugin.MomStepInChance.Value) return;
            _lastMomStep = Time.time; // занято: следующая попытка не раньше кулдауна
            Plugin.Instance.StartCoroutine(Plugin.Instance.MomLater(Plugin.MomStepInDelay.Value));
        }

        // Через несколько секунд после удара (когда значок грусти уже показан) мама выходит к игроку.
        internal static void DoMomStep()
        {
            var cam = GetCameraPos();
            if (!cam.HasValue) return;
            if (UppiesBridge.BeginMomIntervention(cam.Value))
                Plugin.Log.LogInfo("[mom] mama steps in to scold the player (Uppies Please)");
        }

        // Игрок с оружием рядом с раненым или напуганным волчонком: мама рычит.
        internal static void MamaGuardWarn()
        {
            if (MamaFate.Absent || IsCowed()) return;
            var cam = GetCameraPos();
            if (!cam.HasValue) return;
            Plugin.Log.LogInfo("[guard] mama warns the player away from a hurt pup");
            MamaRoarAt(cam.Value);
        }

        // Волчонок с чертой Violent огрызается: 1 урон игроку, не смертельно, с паузой.
        internal static void PupBiteBack(Handle h)
        {
            try
            {
                if (Time.time - _lastPupBite < Plugin.PupBiteCooldown.Value) return;
                var pc = World.playerController;
                if (pc == null || pc.IsKnockedOut || World.gat == null) return;
                var m = World.gat.GetInstanceMatrixImmediate(h);
                var cam = GetCameraPos();
                if (!m.HasValue || !cam.HasValue) return;
                if (Vector3.Distance(m.Value.GetPosition(), cam.Value) > 4f) return;

                _lastPupBite = Time.time;
                int hp = Traverse.Create(pc).Field("health").GetValue<int>();
                if (Plugin.RevengeNonLethal.Value && hp - 1 <= 0)
                {
                    Plugin.Instance.Toast("Щенок огрызается на вас...", 3f);
                    return;
                }
                pc.OnDamage(1);
                _biteDebt += 1;
                _nextPlayerRegen = Time.time + Plugin.PlayerRegenSeconds.Value;
                Plugin.Instance.Toast("Щенок укусил вас в ответ!", 3.5f);
                Plugin.Log.LogInfo("[violent] pup " + h.stableIndex + " bit the player back");
            }
            catch (Exception e) { Plugin.Log.LogWarning("pup bite: " + e.Message); }
        }

        // Волчонка прогнали: волчица недовольна и рычит на игрока.
        internal static void ShooReaction()
        {
            var mama = WolfMama.ActiveInstance;
            if (mama == null || MamaFate.Absent || IsCowed()) return;
            AddTemper(mama, 1);
            try { mama.PlayWoahLines(); } catch (Exception) { }
            var cam = GetCameraPos();
            if (cam.HasValue) MamaRoarAt(cam.Value);
        }

        // Ручной сброс родной ярости (если сохранение застряло на 3/3 из-за старых версий мода).
        public static void ResetRage()
        {
            var mama = WolfMama.ActiveInstance;
            if (mama == null) return;

            int to = Mathf.Clamp(Plugin.ResetRageTo.Value, 0, 3);
            int before = mama.RagePoints;
            Traverse.Create(mama).Field("ragePoints").SetValue(to); // RestoreRagePoints недоступен (internal)
            _temper = 0;
            mama.SetAngry(mama.RagePoints > 0);
            _seenRage = mama.RagePoints;
            Plugin.Log.LogInfo("[mama] ручной сброс родной ярости: " + before + " -> " + mama.RagePoints);
        }

        // Диагностика: пишет в лог, если ярость поменялась не нами (сон, загрузка, другие моды).
        private static void WatchRage()
        {
            if (!Plugin.DebugLog.Value) return;
            var mama = WolfMama.ActiveInstance;
            if (mama == null) { _seenRage = -1; return; }
            int r = mama.RagePoints;
            if (_seenRage >= 0 && r != _seenRage)
                Plugin.Log.LogInfo("[mama] rage changed outside the mod: " + _seenRage + " -> " + r);
            _seenRage = r;
        }

        // Рык на игрока: ставим "цель" в позицию игрока и запускаем родной TryStartRoar.
        // Он проигрывает анимацию standing_scare (со звуком рыка), разворачивает волчицу к цели
        // и через CommandService.MoveUnassignedAgentsTo зовёт свободных волчат к ней.
        private static void MamaRoarAt(Vector3 target)
        {
            try
            {
                var mama = WolfMama.ActiveInstance;
                if (mama == null || MamaFate.Absent || IsCowed()) return;
                if (Vector3.Distance(mama.transform.position, target) > Plugin.RoarMaxDistance.Value) return;
                if (_furyUntil <= 0f && Time.time - _lastRoarAt < Plugin.RoarMinInterval.Value) return; // не чаще раза в N секунд

                var world = World.Instance;
                var hand = world != null && World.playerController != null ? PlayerController.hand : null;
                if (hand != null && hand.IsCarryingGAT(mama.FakeGATHandle)) return;

                var beh = Traverse.Create(mama).Field("_animalBehavior").GetValue<WolfMamaAnimalBehavior>();
                if (beh == null) return;
                var t = Traverse.Create(beh);

                if (t.Field("_roarInProgress").GetValue<bool>()) return;
                if (!t.Field("_trackedAttacker").GetValue<Handle>().isNull) return; // уже рычит на настоящего зверя
                float cd = Mathf.Max(3f, t.Field("roarCooldown").GetValue<float>());
                if (Time.time < t.Field("_lastRoarTime").GetValue<float>() + cd) return;

                t.Method("SetTrackedAttacker", new Type[] { typeof(Handle), typeof(Vector3) },
                         new object[] { Handle.Null, target }).GetValue();
                t.Method("TryStartRoar").GetValue();
                _lastRoarAt = Time.time;

                Plugin.Instance.StartCoroutine(Plugin.Instance.ClearTrackedLater(beh, Plugin.RoarClearDelay.Value));
                if (Plugin.RevengeEnabled.Value)
                    Plugin.Instance.StartCoroutine(Plugin.Instance.RevengeLater(0.9f));

                if (Plugin.DebugLog.Value) Plugin.Log.LogInfo("[mama] roars at player");
            }
            catch (Exception e) { Plugin.Log.LogWarning("roar: " + e.Message); }
        }

        // Повышает нрав волчицы и злит её. Таймер успокоения идёт с последнего такого события.
        private static void AddTemper(WolfMama mama, int points)
        {
            _temperOwner = mama;
            _temper = Mathf.Clamp(_temper + points, 0, Mathf.Max(1, Plugin.MaxTemper.Value));
            _nextCalm = Time.time + Plugin.RageDecaySeconds.Value;
            mama.SetAngry(true);
        }

        // ---------------- мясо ----------------

        private static SpawnGroup[] _meatGroups;
        private static bool _dropsLogged, _meatWarned;

        private static string[] MeatNeedles()
        {
            var list = new List<string>();
            foreach (string p in (Plugin.MeatTemplateName.Value ?? "").Split(','))
            {
                string t = p.Trim().ToLowerInvariant();
                if (t.Length > 0) list.Add(t);
            }
            return list.ToArray();
        }

        // Есть ли у шаблона свой дроп (тогда игра сама его выбросит, мясо добавлять не нужно).
        private static bool HasAnyDrop(Template tmpl)
        {
            if (tmpl == null || tmpl.spawnGroups == null) return false;
            foreach (var sg in tmpl.spawnGroups)
                if (sg != null && sg.spawnTemplate != null) return true;
            return false;
        }

        // Ищем предмет мяса среди дропов других существ (чтобы взять и сам предмет, и его физический префаб).
        private static SpawnGroup[] FindMeatGroups()
        {
            var world = World.Instance;
            if (world == null || World.gat == null) return null;
            var entries = World.gat.GetTemplateEntries();
            if (entries == null) return null;

            bool log = Plugin.DebugLog.Value && !_dropsLogged;
            var allGroups = new List<SpawnGroup>();
            var allTemplates = new List<Template>();
            var names = new List<string>();

            for (int i = 0; i < entries.Count; i++)
            {
                var tmpl = entries[i].template;
                if (tmpl == null) continue;
                allTemplates.Add(tmpl);
                names.Add(tmpl.name);

                var groups = tmpl.spawnGroups;
                if (groups == null) continue;
                foreach (var sg in groups)
                {
                    if (sg == null || sg.spawnTemplate == null) continue;
                    allGroups.Add(sg);
                    if (log)
                        Plugin.Log.LogInfo("[drops] '" + tmpl.name + "' drops '" + sg.spawnTemplate.name +
                            "' (min " + sg.minSpawnCount + ", extra " + sg.randomExtraSpawnCount + ")");
                }
            }
            if (log)
            {
                _dropsLogged = true;
                Plugin.Log.LogInfo("[drops] all templates: " + string.Join(", ", names.ToArray()));
            }

            var group = new SpawnGroup();
            bool found = false;
            foreach (string needle in MeatNeedles())
            {
                foreach (var sg in allGroups)
                {
                    if (sg.spawnTemplate.name.ToLowerInvariant().Contains(needle))
                    {
                        group.spawnTemplate = sg.spawnTemplate;
                        group.rigidTransformPrefab = sg.rigidTransformPrefab;
                        found = true;
                        break;
                    }
                }
                if (found) break;
                foreach (var t in allTemplates)
                {
                    if (t.name.ToLowerInvariant().Contains(needle))
                    {
                        group.spawnTemplate = t;
                        found = true;
                        break;
                    }
                }
                if (found) break;
            }
            if (!found) return null;

            group.minSpawnCount = Mathf.Max(1, Plugin.MeatMin.Value);
            group.randomExtraSpawnCount = Mathf.Max(0, Plugin.MeatExtra.Value);
            return new[] { group };
        }

        // Точное количество кусков мяса (для останков волчицы): число задаётся через minSpawnCount.
        internal static void DropMeatAmount(Vector3 pos, int amount)
        {
            try
            {
                if (World.gatUtilities == null) return;
                if (_meatGroups == null) _meatGroups = FindMeatGroups();
                if (_meatGroups == null)
                {
                    Plugin.Log.LogWarning("[meat] предмет мяса не найден: останки волчицы будут без мяса (см. [Meat] ItemNames)");
                    return;
                }
                var src = _meatGroups[0];
                var g = new SpawnGroup();
                g.spawnTemplate = src.spawnTemplate;
                g.rigidTransformPrefab = src.rigidTransformPrefab;
                g.minSpawnCount = Mathf.Max(1, amount);
                g.randomExtraSpawnCount = 0;
                World.gatUtilities.CreateTemplateSpawnGroups(new[] { g }, pos, null, null, null);
                Plugin.Log.LogInfo("[meat] remains: " + g.minSpawnCount + " x '" + g.spawnTemplate.name + "'");
            }
            catch (Exception e) { Plugin.Log.LogWarning("meat remains: " + e.Message); }
        }

        private static void DropMeat(Vector3 pos)
        {
            try
            {
                var world = World.Instance;
                if (world == null || World.gatUtilities == null) return;

                if (_meatGroups == null) _meatGroups = FindMeatGroups();
                if (_meatGroups == null)
                {
                    if (!_meatWarned)
                    {
                        _meatWarned = true;
                        Plugin.Log.LogWarning("[meat] предмет мяса не найден (ищу '" + Plugin.MeatTemplateName.Value +
                            "'). Посмотри строки [drops] в логе и поправь Meat.ItemNames");
                    }
                    return;
                }

                // Тот же вызов, что и в KillInstance для дропа, только с нашей группой.
                World.gatUtilities.CreateTemplateSpawnGroups(_meatGroups, pos, null, null, null);
                if (Plugin.DebugLog.Value)
                    Plugin.Log.LogInfo("[meat] dropped '" + _meatGroups[0].spawnTemplate.name + "'");
            }
            catch (Exception e) { Plugin.Log.LogWarning("meat: " + e.Message); }
        }

        // ---------------- шок ----------------

        private static readonly HashSet<string> LoggedAnimTemplates = new HashSet<string>();
        
        // Волчица: ахает, злится, рычит на игрока. Волчата: вздрагивают, кучкуются, часть пищит.
        // Используются родные механизмы игры: PlayWoahLines, анимации STARTLE/ALERT,
        // GATDumbFleeHuddleBehavior (так игра сама прячет волчат от опасности) и Autonomy.PlayFleeSound.
        private static void Shock()
        {
            var world = World.Instance;
            if (world == null) return;

            var mama = WolfMama.ActiveInstance;
            if (mama != null && !MamaFate.Absent && !IsCowed())
            {
                try
                {
                    mama.PlayWoahLines();
                    mama.SetAngry(true);
                    if (Plugin.ShockMamaRage.Value > 0) AddTemper(mama, Plugin.ShockMamaRage.Value);
                    Plugin.Instance.StartCoroutine(Plugin.Instance.CalmAngryLater(mama, Plugin.ShockSeconds.Value));

                    if (UnityEngine.Random.value < Plugin.ShockRoarChance.Value)
                    {
                        var cam = GetCameraPos();
                        if (cam.HasValue) MamaRoarAt(cam.Value);
                    }
                }
                catch (Exception e) { Plugin.Log.LogWarning("shock/mama: " + e.Message); }
            }

            if (World.gatUtilities != null)
                World.gatUtilities.GetInstancesByFaction(Faction.PLAYER, list => OnFamilyExtracted(list));
        }

        private static void OnFamilyExtracted(IReadOnlyList<InstanceDataExtraction> list)
        {
            try
            {
                var world = World.Instance;
                if (world == null || list == null) return;
                var gat = World.gat;
                if (gat == null) return;
                var hand = World.playerController != null ? PlayerController.hand : null;

                var all = new List<Handle>(list.Count);
                var byTemplate = new Dictionary<Template, List<Handle>>();
                for (int i = 0; i < list.Count; i++)
                {
                    Handle h = new Handle();
                    h.stableIndex = list[i].stableIndex;
                    if (!gat.IsHandleValid(h)) continue;
                    if (hand != null && hand.IsCarryingGAT(h)) continue; // тех, кто на руках, не трогаем

                    var tmpl = gat.GetTemplateFromHandle(h);
                    if (tmpl == null) continue;
                    if (tmpl.name.ToLowerInvariant().Contains("fake")) continue; // fake_player_GAT - служебный, не волчонок
                    all.Add(h);
                    List<Handle> bucket;
                    if (!byTemplate.TryGetValue(tmpl, out bucket))
                    {
                        bucket = new List<Handle>();
                        byTemplate[tmpl] = bucket;
                    }
                    bucket.Add(h);
                }
                if (all.Count == 0) return;

                // 1) вздрагивание
                var anim = World.gatAnimationManager;
                if (anim != null)
                {
                    foreach (var kv in byTemplate)
                    {
                        AnimationEnum? ae = PickShockAnim(kv.Key);
                        if (ae == null) continue;
                        try { anim.PlayAnimations(kv.Value.ToArray(), ae.Value, 0, true, null, kv.Key, false); }
                        catch (Exception e) { Plugin.Log.LogWarning("shock anim: " + e.Message); }
                    }
                }

                // 2) поведение: кучкуются (false) или разбегаются (true)
                var huddle = World.gatFleeHuddleBehavior;
                if (huddle != null)
                {
                    bool scatter = Plugin.ShockScatter.Value;
                    float secs = Plugin.ShockSeconds.Value;
                    foreach (Handle h in all) huddle.Add(h, scatter, secs);
                }

                // 3) голоса у нескольких случайных
                int n = Mathf.Min(Plugin.ShockMaxSounds.Value, all.Count);
                for (int k = 0; k < n; k++) PlayVoiceFor(all[UnityEngine.Random.Range(0, all.Count)]);

                if (Plugin.DebugLog.Value)
                    Plugin.Log.LogInfo("[shock] " + all.Count + " family members reacted (" +
                        (Plugin.ShockScatter.Value ? "scatter" : "huddle") + ", " + n + " voices)");
            }
            catch (Exception e) { Plugin.Log.LogWarning("shock: " + e.Message); }
        }

        // Анимация испуга: STARTLE, иначе ALERT - если она есть у шаблона.
        private static AnimationEnum? PickShockAnim(Template tmpl)
        {
            AnimationEnum[] order = { AnimationEnum.STARTLE, AnimationEnum.ALERT };
            foreach (AnimationEnum e in order)
            {
                string n = null;
                try { n = tmpl.GetAnimationName(e); } catch (Exception) { }
                if (string.IsNullOrEmpty(n)) continue;
                if (Plugin.DebugLog.Value && LoggedAnimTemplates.Add(tmpl.name))
                    Plugin.Log.LogInfo("[shock] template '" + tmpl.name + "' reacts with " + e + " ('" + n + "')");
                return e;
            }
            if (Plugin.DebugLog.Value && LoggedAnimTemplates.Add(tmpl.name))
                Plugin.Log.LogInfo("[shock] template '" + tmpl.name + "' has no STARTLE/ALERT animation");
            return null;
        }

        // Голос волчонку: позицию узнаём так же, как это делает игра (GetInstanceMatrixAsync),
        // группа звука - из списка HurtSounds (у волчат нет FLEE, поэтому родной PlayFleeSound молчит).
        private static void PlayVoiceFor(Handle h)
        {
            var world = World.Instance;
            if (world == null) return;
            var gat = World.gat;
            if (gat == null) return;
            gat.GetInstanceMatrixAsync(h, m =>
            {
                try
                {
                    if (!m.HasValue || !gat.IsHandleValid(h)) return;
                    PlayHurtSound(h, m.Value.GetPosition());
                }
                catch (Exception e) { Plugin.Log.LogWarning("voice: " + e.Message); }
            });
        }

        private static float DistPointSegment(Vector3 p, Vector3 a, Vector3 b)
        {
            Vector3 ab = b - a;
            float t = Mathf.Clamp01(Vector3.Dot(p - a, ab) / Mathf.Max(ab.sqrMagnitude, 1e-6f));
            return Vector3.Distance(p, a + ab * t);
        }
    }

    // ---------------------------------------------------------------------
    // Ранения, лечение и страх (только для волчат, которых ударил игрок)
    // ---------------------------------------------------------------------
    internal static class Injury
    {
        private sealed class PupState
        {
            public Handle h;
            public float fearUntil;
            public float nextWhimper;
            public float nextRegen;
            public float nextFlee;
            public float seekUntil;   // пока он бежит к маме
            public float seekStartAt; // когда он побежит (после значка грусти)
            public bool seekStarted;
            public float nextReseek;
            public bool wounded;
        }

        private static readonly Dictionary<ushort, PupState> Tracked = new Dictionary<ushort, PupState>();
        private static readonly List<ushort> ToRemove = new List<ushort>();
        private static float _nextTick;
        private static bool _healWarned;

        // Волчонка ударили, и он выжил.
        public static void OnHurt(Handle h)
        {
            float now = Time.time;
            PupState st;
            if (!Tracked.TryGetValue(h.stableIndex, out st))
            {
                st = new PupState();
                st.nextWhimper = now + Plugin.WhimperSeconds.Value * UnityEngine.Random.Range(0.5f, 1f);
                Tracked[h.stableIndex] = st;
            }
            st.h = h;
            st.nextRegen = now + Plugin.RegenSeconds.Value; // новый ушиб сбрасывает таймер лечения

            // доверие и характер определяют, насколько долго он боится и обижается
            Profile prof = Pups.Get(h);
            float mul = Pups.FearMul(prof);
            Pups.OnHurt(prof);

            // побежит к маме за утешением (характер, доверие и черты Pup Traits меняют шанс)
            if (Plugin.SeekMamaChance.Value > 0f &&
                UnityEngine.Random.value < Plugin.SeekMamaChance.Value * Pups.SeekMamaMul(prof, h))
                StartSeekMama(st);

            // Violent (Pup Traits): может огрызнуться
            if (Plugin.ViolentBiteBack.Value && TraitsBridge.HasTrait(h, TraitsBridge.Violent) &&
                UnityEngine.Random.value < 0.5f)
                Combat.PupBiteBack(h);

            if (Plugin.FearEnabled.Value)
                st.fearUntil = Mathf.Min(Mathf.Max(st.fearUntil, now) + Plugin.FearSecondsPerHit.Value * mul,
                                         now + Plugin.MaxFearSeconds.Value);

            if (Plugin.OffendedEnabled.Value)
            {
                UppiesBridge.Offend(h, Plugin.OffendedCooldown.Value * mul);
                Plugin.Instance.StartCoroutine(Plugin.Instance.OffendedSoundLater(h, Plugin.OffendedSoundDelay.Value));
            }

            if (Plugin.Verbose.Value)
                Plugin.Log.LogInfo("[injury] handle " + h.stableIndex + " hurt; afraid for " +
                    Mathf.Max(0f, st.fearUntil - now).ToString("F0") + "s; tracked=" + Tracked.Count);
        }

        private static float _nextGuard;

        // Раненый или напуганный: такие волчата не отпускаются бродить (Pups Wander).
        public static bool IsHurtOrAfraid(Handle h)
        {
            PupState st;
            if (!Tracked.TryGetValue(h.stableIndex, out st)) return false;
            return st.wounded || Time.time < st.fearUntil || st.seekUntil > Time.time;
        }

        // Отправить волчонка к маме готовой командой движения игры (радиус цели 2, как у Uppies Please).
        private static void SendToMama(Handle h, Vector3 mamaPos)
        {
            var cmd = World.gatCommandManager;
            if (cmd == null) return;
            var mover = cmd.GetCommand<GATMoveBehavior>();
            if (mover == null) return;
            mover.CommandMove(new[] { h }, mamaPos, 2, false);
        }

        private static void StartSeekMama(PupState st)
        {
            try
            {
                var mama = WolfMama.ActiveInstance;
                if (mama == null || MamaFate.Absent) return;
                float now = Time.time;
                st.seekStartAt = now + Plugin.SeekMamaDelay.Value;
                st.seekUntil = st.seekStartAt + Plugin.SeekMamaSeconds.Value;
                st.nextReseek = st.seekStartAt;
                st.seekStarted = false;
                if (Plugin.Verbose.Value) Plugin.Log.LogInfo("[comfort] pup " + st.h.stableIndex + " will run to the mama in " + Plugin.SeekMamaDelay.Value.ToString("F0") + "s");
            }
            catch (Exception e) { Plugin.Log.LogWarning("seek mama: " + e.Message); }
        }

        // Волчонок добежал до мамы: мама смотрит на него, он успокаивается, лечится и возвращает часть доверия.
        private static void Comfort(PupState st, Vector3 pos, WolfMama mama)
        {
            st.seekUntil = 0f;
            st.seekStarted = false;
            st.fearUntil = Mathf.Min(st.fearUntil, Time.time);

            var world = World.Instance;
            int hp, maxHp, hunger;
            if (world != null && ReadHp(world, st.h, out hp, out maxHp, out hunger))
            {
                int amount = Mathf.Min(Plugin.ComfortHeal.Value, maxHp - hp);
                if (amount > 0) Heal(st.h, pos, amount, 0);
            }
            Pups.Comfort(Pups.Get(st.h), Plugin.ComfortTrust.Value);
            try { mama.LookAtTemporary(st.h); } catch (Exception) { }
            UppiesBridge.ShowIcon(st.h, "Mama", 5f);
            Plugin.Log.LogInfo("[comfort] pup " + st.h.stableIndex + " was comforted by the mama");
        }

        // Раз в секунду: лечение, скулёж, побег от игрока.
        public static void Tick()
        {
            MaybeScan();
            if (Tracked.Count == 0 || Time.time < _nextTick) return;
            _nextTick = Time.time + 1f;

            var world = World.Instance;
            if (world == null || World.gat == null) return;
            var gat = World.gat;
            var hand = World.playerController != null ? PlayerController.hand : null;
            var cam = Combat.GetCameraPos();
            float now = Time.time;

            var mamaObj = WolfMama.ActiveInstance;
            bool hasMama = mamaObj != null && !MamaFate.Absent;
            Vector3 mamaPos = hasMama ? mamaObj.transform.position : Vector3.zero;

            bool armed = false; // игрок с топором или лопатой
            var tool = World.playerController != null ? World.playerController.CurrentTool : null;
            if (tool != null)
            {
                var te = tool.toolEnum;
                armed = te == Tool.ToolEnum.AXE || te == Tool.ToolEnum.SHOVEL;
            }
            bool guardTrigger = false;

            ToRemove.Clear();
            foreach (var kv in Tracked)
            {
                PupState st = kv.Value;
                if (!gat.IsHandleValid(st.h)) { ToRemove.Add(kv.Key); continue; }

                int hp, maxHp, hunger;
                if (!ReadHp(world, st.h, out hp, out maxHp, out hunger)) continue;

                bool carried = hand != null && hand.IsCarryingGAT(st.h);
                var m = gat.GetInstanceMatrixImmediate(st.h);
                Vector3 pos = m.HasValue ? m.Value.GetPosition() : Vector3.zero;

                // --- утешение у мамы ---
                bool nearMama = hasMama && m.HasValue && Vector3.Distance(pos, mamaPos) <= Plugin.ComfortDistance.Value;
                if (st.seekUntil > now)
                {
                    if (now >= st.seekStartAt) // сначала значок грусти, потом бежит к маме
                    {
                        if (nearMama && !carried) Comfort(st, pos, mamaObj);
                        else if (hasMama && now >= st.nextReseek) { st.nextReseek = now + 6f; st.seekStarted = true; SendToMama(st.h, mamaPos); } // мама двигается
                    }
                }
                else if (st.seekUntil > 0f) { st.seekUntil = 0f; st.seekStarted = false; }

                // --- лечение ---
                if (Plugin.HealEnabled.Value && hp < maxHp && now >= st.nextRegen)
                {
                    if (hunger > 0 && !carried)
                    {
                        st.nextRegen = now + 5f; // голодный не лечится
                    }
                    else
                    {
                        Heal(st.h, pos, 1, 0);
                        float interval = carried ? Plugin.CarriedRegenSeconds.Value : Plugin.RegenSeconds.Value;
                        if (nearMama) interval *= Plugin.NearMamaRegenFactor.Value; // рядом с мамой лечится быстрее
                        st.nextRegen = now + interval;
                    }
                }

                // --- ранен: скулит ---
                bool wounded = hp <= maxHp * Plugin.WoundedFraction.Value;
                st.wounded = wounded;

                // --- мама на страже: игрок с оружием рядом с раненым или напуганным ---
                if (armed && cam.HasValue && m.HasValue && (wounded || now < st.fearUntil) &&
                    Vector3.Distance(pos, cam.Value) <= Plugin.GuardRadius.Value) guardTrigger = true;
                if (Plugin.InjuryEnabled.Value && wounded && !carried && now >= st.nextWhimper)
                {
                    var tmpl = gat.GetTemplateFromHandle(st.h);
                    var anim = World.gatAnimationManager;
                    if (anim != null && tmpl != null)
                    {
                        try { anim.PlayAnimations(new[] { st.h }, AnimationEnum.PAIN, 0, true, null, tmpl, false); }
                        catch (Exception) { }
                    }
                    if (m.HasValue) Combat.PlayHurtSound(st.h, pos);
                    st.nextWhimper = now + Plugin.WhimperSeconds.Value * UnityEngine.Random.Range(0.7f, 1.3f);
                }

                // --- страх: убегает, если игрок близко ---
                if (Plugin.FearEnabled.Value && now < st.fearUntil && !carried && now >= st.nextFlee && (!st.seekStarted || st.seekUntil <= now) &&
                    cam.HasValue && m.HasValue &&
                    Vector3.Distance(pos, cam.Value) <= Plugin.FearRadius.Value * Pups.RadiusMul(Pups.Get(st.h)))
                {
                    var huddle = World.gatFleeHuddleBehavior;
                    if (huddle != null) huddle.Add(st.h, true, Plugin.FleeSeconds.Value);
                    st.nextFlee = now + Plugin.FleeCooldown.Value;
                    if (Plugin.Verbose.Value) Plugin.Log.LogInfo("[fear] handle " + st.h.stableIndex + " runs from the player");
                }

                // --- всё прошло: больше не отслеживаем ---
                if (hp >= maxHp && now >= st.fearUntil) ToRemove.Add(kv.Key);
            }

            foreach (ushort k in ToRemove) Tracked.Remove(k);

            if (guardTrigger && Plugin.GuardEnabled.Value && now >= _nextGuard)
            {
                _nextGuard = now + Plugin.GuardCooldown.Value;
                Combat.MamaGuardWarn();
            }
        }

        public static int WoundedCount()
        {
            var world = World.Instance;
            if (world == null || World.gat == null) return 0;
            int n = 0;
            foreach (var st in Tracked.Values)
            {
                int hp, maxHp, hunger;
                if (!World.gat.IsHandleValid(st.h)) continue;
                if (ReadHp(world, st.h, out hp, out maxHp, out hunger) && hp <= maxHp * Plugin.WoundedFraction.Value) n++;
            }
            return n;
        }

        // Периодически ищем среди всех волчат тех, у кого здоровье не полное (после загрузки игры и т.п.).
        private static float _nextScan = -1f;

        private static void MaybeScan()
        {
            if (!Plugin.HealEnabled.Value && !Plugin.TrustEnabled.Value && !Plugin.TemperamentEnabled.Value) return;
            float now = Time.time;
            if (_nextScan < 0f) { _nextScan = now + 10f; return; }
            if (now < _nextScan) return;
            _nextScan = now + Mathf.Max(10f, Plugin.RescanSeconds.Value);

            var world = World.Instance;
            if (world == null || World.gatUtilities == null) return;
            World.gatUtilities.GetInstancesByFaction(Faction.PLAYER, list => OnScan(list));
        }

        private static void OnScan(IReadOnlyList<InstanceDataExtraction> list)
        {
            try
            {
                var world = World.Instance;
                if (world == null || list == null || World.gat == null) return;

                int added = 0;
                var present = new HashSet<ushort>();
                int realCount = 0;
                for (int i = 0; i < list.Count; i++)
                {
                    Handle h = new Handle();
                    h.stableIndex = list[i].stableIndex;
                    present.Add(h.stableIndex);
                    if (!World.gat.IsHandleValid(h)) continue;

                    var tmpl = World.gat.GetTemplateFromHandle(h);
                    if (tmpl == null || tmpl.name.ToLowerInvariant().Contains("fake")) continue;
                    realCount++;
                    Pups.Get(h); // профиль (доверие, характер) для каждого волчонка
                    if (Tracked.ContainsKey(h.stableIndex)) continue;

                    int hp, maxHp, hunger;
                    if (!ReadHp(world, h, out hp, out maxHp, out hunger)) continue;
                    if (hp >= maxHp) continue;

                    var st = new PupState();
                    st.h = h;
                    st.nextRegen = Time.time + Plugin.RegenSeconds.Value;
                    st.nextWhimper = Time.time + Plugin.WhimperSeconds.Value * UnityEngine.Random.Range(0.5f, 1f);
                    Tracked[h.stableIndex] = st;
                    added++;
                }
                if (list.Count > 0)
                {
                    Pups.Purge(present);
                    Strays.OnFamilyCount(realCount);
                }
                if (added > 0 && Plugin.DebugLog.Value)
                    Plugin.Log.LogInfo("[heal] scan: found " + added + " wounded pups, tracked=" + Tracked.Count);
            }
            catch (Exception e) { Plugin.Log.LogWarning("scan: " + e.Message); }
        }

        // Ночью все отслеживаемые волчата восстанавливают здоровье.
        public static void OnSleep()
        {
            if (!Plugin.HealEnabled.Value || Tracked.Count == 0) return;
            var world = World.Instance;
            if (world == null || World.gat == null) return;

            int n = 0;
            foreach (var st in Tracked.Values)
            {
                if (!World.gat.IsHandleValid(st.h)) continue;
                int hp, maxHp, hunger;
                if (!ReadHp(world, st.h, out hp, out maxHp, out hunger)) continue;
                int amount = Mathf.Min(Plugin.HealOnSleep.Value, maxHp - hp);
                if (amount <= 0) continue;

                var m = World.gat.GetInstanceMatrixImmediate(st.h);
                Heal(st.h, m.HasValue ? m.Value.GetPosition() : Vector3.zero, amount, 0);
                st.nextRegen = Time.time + Plugin.RegenSeconds.Value;
                n++;
            }
            if (Plugin.Verbose.Value) Plugin.Log.LogInfo("[heal] slept: " + n + " pups healed");
        }

        public static void PlayOffendedSound(Handle h)
        {
            var world = World.Instance;
            if (world == null || World.gat == null || !World.gat.IsHandleValid(h)) return;
            var m = World.gat.GetInstanceMatrixImmediate(h);
            if (!m.HasValue) return;
            Combat.PlaySoundFromList(h, m.Value.GetPosition(), Combat.ParseGroups(Plugin.OffendedSounds.Value));
        }

        private static bool ReadHp(World world, Handle h, out int hp, out int maxHp, out int hunger)
        {
            hp = 0; maxHp = 10; hunger = 0;
            var gat = World.gat;
            GATInstanceInfo info = default(GATInstanceInfo);
            if (!gat.TryGetInstanceInfoImmediate(h, out info)) return false;
            hp = info.health;
            hunger = info.hunger;
            var tmpl = gat.GetTemplateFromHandle(h);
            if (tmpl != null) maxHp = Mathf.Max(1, (int)tmpl.startHealth);
            return true;
        }

        // Положительный ApplyHealthDelta. attempt 0: источник = сам волчонок;
        // если игра не приняла (effectiveDelta <= 0), attempt 1: источник = волчица.
        private static void Heal(Handle h, Vector3 pos, int amount, int attempt)
        {
            var world = World.Instance;
            if (world == null || World.gatUtilities == null || World.gat == null) return;
            if (!World.gat.IsHandleValid(h)) return;

            Handle source = h;
            if (attempt == 1)
            {
                var mama = WolfMama.ActiveInstance;
                if (mama == null) return;
                source = mama.FakeGATHandle;
            }

            World.gatUtilities.ApplyHealthDelta(pos, source, h, (short)Mathf.Abs(amount), 100f, res =>
            {
                if (Plugin.Verbose.Value)
                    Plugin.Log.LogInfo("[heal] handle " + h.stableIndex + " attempt=" + attempt +
                        " effective=" + res.effectiveDelta + " hp=" + res.currentValue);
                if (res.effectiveDelta > 0) return;
                if (attempt == 0) { Heal(h, pos, amount, 1); return; }
                if (!_healWarned)
                {
                    _healWarned = true;
                    Plugin.Log.LogWarning("[heal] игра не приняла положительный ApplyHealthDelta, лечение не работает");
                }
            });
        }
    }

    // ---------------------------------------------------------------------
    // Мост к моду Uppies Please (через рефлексию; если мода нет - молча ничего не делает)
    // ---------------------------------------------------------------------
    internal static class UppiesBridge
    {
        private static bool _initTried, _available, _failedLogged;
        private static Type _type, _kindType;

        private static bool Init()
        {
            if (!Plugin.LinkMods.Value) return false;
            if (_initTried) return _available;
            _initTried = true;
            try
            {
                _type = Util.FindType("FamilyTimeMods.UppiesPlease.UppiesPlease");
                if (_type == null)
                {
                    Plugin.Log.LogInfo("[offended] Uppies Please не найден, интеграция выключена");
                    return false;
                }
                _kindType = AccessTools.Inner(_type, "ReactionKind");
                _available = true;
                Plugin.Log.LogInfo("[offended] Uppies Please найден, интеграция включена");
            }
            catch (Exception e) { Plugin.Log.LogWarning("[offended] init: " + e.Message); }
            return _available;
        }

        // Значок реакции над головой волчонка (Sad, Angry, Happy, Mama и т.д.).
        public static void ShowIcon(Handle h, string kind, float seconds)
        {
            if (!Init() || _kindType == null) return;
            try
            {
                object inst = Traverse.Create(_type).Field("instance").GetValue();
                if (inst == null) return;
                object k = Enum.Parse(_kindType, kind, true);
                Traverse.Create(inst).Method("ShowGameCue", new Type[] { typeof(Handle), _kindType, typeof(float) },
                                             new object[] { h, k, seconds }).GetValue();
            }
            catch (Exception) { }
        }

        // Запускает сцену Uppies Please "мама выходит к игроку и отчитывает его". true, если сцена началась.
        // Сцена рассчитана на толпу просящихся волчат: без них она обрывается в тот же кадр, но успевает
        // сдвинуть собственное расписание Uppies. Поэтому запускаем её только при наличии просящихся,
        // возвращаем расписание на место и ставим страховку на случай, если сцена не закончится сама.
        public static bool BeginMomIntervention(Vector3 playerPos)
        {
            if (MamaFate.Absent || !Init()) return false;
            try
            {
                object inst = Traverse.Create(_type).Field("instance").GetValue();
                if (inst == null) return false;
                var t = Traverse.Create(inst);
                if (t.Field("momApproaching").GetValue<bool>()) return false; // сцена уже идёт

                var wishes = t.Field("wishes").GetValue<System.Collections.IDictionary>();
                if (wishes == null || wishes.Count == 0) return false;

                float savedNext = t.Field("nextFamilyScene").GetValue<float>();
                t.Method("BeginMomIntervention", new Type[] { typeof(Vector3) }, new object[] { playerPos }).GetValue();
                bool started = t.Field("momApproaching").GetValue<bool>();
                t.Field("nextFamilyScene").SetValue(savedNext); // расписание Uppies не сдвигаем

                if (started) Plugin.Instance.StartCoroutine(Plugin.Instance.MomWatchdog(26f));
                return started;
            }
            catch (Exception e)
            {
                if (!_failedLogged) { _failedLogged = true; Plugin.Log.LogWarning("[mom] " + e.Message); }
                return false;
            }
        }

        // Страховка: если сцена мамы не закончилась сама, завершаем её (иначе Free Roam считает маму занятой).
        public static void EndMomIfStuck()
        {
            if (!_available) return;
            try
            {
                object inst = Traverse.Create(_type).Field("instance").GetValue();
                if (inst == null) return;
                var t = Traverse.Create(inst);
                if (t.Field("momApproaching").GetValue<bool>())
                {
                    t.Method("EndMomApproach").GetValue();
                    Plugin.Log.LogInfo("[mom] сцена мамы не закончилась сама: завершена принудительно");
                }
            }
            catch (Exception) { }
        }

        // Ударенный волчонок: сразу перестаёт проситься на ручки и не попросится до конца кулдауна.
        public static void Offend(Handle h, float cooldownSeconds)
        {
            if (!Init()) return;
            try
            {
                object inst = Traverse.Create(_type).Field("instance").GetValue();
                var world = World.Instance;
                if (inst == null || world == null) return;
                var t = Traverse.Create(inst);

                // 1) убрать текущее желание (заодно останавливает его бег к игроку)
                t.Method("RemoveWish", new Type[] { typeof(World), typeof(Handle) }, new object[] { world, h }).GetValue();

                // 2) пока не пройдёт кулдаун, новое желание у него не начнётся
                var cooldowns = t.Field("childCooldowns").GetValue<Dictionary<Handle, float>>();
                if (cooldowns != null)
                {
                    float until = Time.unscaledTime + cooldownSeconds;
                    float old;
                    if (!cooldowns.TryGetValue(h, out old) || old < until) cooldowns[h] = until;
                }

                // 3) значок обиды над головой
                if (_kindType != null)
                {
                    object kind = Enum.Parse(_kindType, Plugin.OffendedIcon.Value, true);
                    t.Method("ShowGameCue", new Type[] { typeof(Handle), _kindType, typeof(float) },
                             new object[] { h, kind, Plugin.OffendedIconSeconds.Value }).GetValue();
                }

                if (Plugin.Verbose.Value)
                    Plugin.Log.LogInfo("[offended] handle " + h.stableIndex + " больше не просится на ручки " +
                        cooldownSeconds.ToString("F0") + "s");
            }
            catch (Exception e)
            {
                if (!_failedLogged)
                {
                    _failedLogged = true;
                    Plugin.Log.LogWarning("[offended] не вышло: " + e.Message);
                }
            }
        }
    }

    // ---------------------------------------------------------------------
    // Доверие и характер каждого волчонка (хранится в файле по имени сохранения)
    // ---------------------------------------------------------------------
    internal enum Temperament : byte { Normal = 0, Brave = 1, Timid = 2 }

    internal sealed class Profile
    {
        public float trust;
        public Temperament temper;
        public bool feral;   // бродячий: ушёл из семьи или чужой щенок
        public int shoos;    // сколько раз подряд его прогнали
    }

    internal static class Pups
    {
        private static readonly Dictionary<ushort, Profile> Profiles = new Dictionary<ushort, Profile>();
        private static string _loadedFor;
        private static bool _dirty;
        private static float _nextTick, _nextSave;

        public static Profile Get(Handle h)
        {
            EnsureLoaded();
            Profile p;
            if (!Profiles.TryGetValue(h.stableIndex, out p))
            {
                p = NewProfile();
                Temperament fromTraits;
                if (TraitsBridge.TryGetTemperament(h, out fromTraits)) p.temper = fromTraits; // характер из Pup Traits
                Profiles[h.stableIndex] = p;
                _dirty = true;
                if (Plugin.Verbose.Value)
                    Plugin.Log.LogInfo("[pups] handle " + h.stableIndex + ": " + p.temper + ", trust " + p.trust.ToString("F0"));
            }
            return p;
        }

        private static Profile NewProfile()
        {
            var p = new Profile();
            p.trust = Plugin.TrustStart.Value;
            p.temper = Temperament.Normal;
            if (Plugin.TemperamentEnabled.Value)
            {
                float r = UnityEngine.Random.value * 100f;
                int brave = Mathf.Clamp(Plugin.BravePercent.Value, 0, 100);
                int timid = Mathf.Clamp(Plugin.TimidPercent.Value, 0, 100 - brave);
                if (r < brave) p.temper = Temperament.Brave;
                else if (r < brave + timid) p.temper = Temperament.Timid;
            }
            return p;
        }

        // Во сколько раз страх и обида длиннее (>1) или короче (<1) обычного.
        public static float FearMul(Profile p)
        {
            float tf = Plugin.TrustEnabled.Value ? Mathf.Lerp(1.5f, 0.6f, Mathf.Clamp01(p.trust / 100f)) : 1f;
            float tm = 1f;
            if (Plugin.TemperamentEnabled.Value)
                tm = p.temper == Temperament.Brave ? 0.6f : (p.temper == Temperament.Timid ? 1.5f : 1f);
            return tf * tm;
        }

        // Во сколько раз радиус, с которого он убегает от игрока, больше обычного.
        public static float RadiusMul(Profile p)
        {
            float tf = Plugin.TrustEnabled.Value ? Mathf.Lerp(1.3f, 0.7f, Mathf.Clamp01(p.trust / 100f)) : 1f;
            float tm = 1f;
            if (Plugin.TemperamentEnabled.Value)
                tm = p.temper == Temperament.Brave ? 0.8f : (p.temper == Temperament.Timid ? 1.2f : 1f);
            return tf * tm;
        }

        // Утешение мамой возвращает часть доверия.
        public static void Comfort(Profile p, float amount)
        {
            if (!Plugin.TrustEnabled.Value) return;
            p.trust = Mathf.Min(100f, p.trust + amount);
            _dirty = true;
        }

        // Во сколько раз чаще или реже волчонок бежит к маме (характер, доверие, черты Pup Traits).
        public static float SeekMamaMul(Profile p, Handle h)
        {
            float tf = Plugin.TrustEnabled.Value ? Mathf.Lerp(1.3f, 0.8f, Mathf.Clamp01(p.trust / 100f)) : 1f;
            float tm = 1f;
            if (Plugin.TemperamentEnabled.Value)
                tm = p.temper == Temperament.Timid ? 1.3f : (p.temper == Temperament.Brave ? 0.6f : 1f);
            float tr = 1f;
            if (TraitsBridge.HasTrait(h, TraitsBridge.Clingy)) tr *= 1.4f;
            if (TraitsBridge.HasTrait(h, TraitsBridge.Scared)) tr *= 1.2f;
            return tf * tm * tr;
        }

        public static void OnHurt(Profile p)
        {
            if (!Plugin.TrustEnabled.Value) return;
            float lossMul = 1f;
            if (Plugin.TemperamentEnabled.Value)
                lossMul = p.temper == Temperament.Brave ? 0.7f : (p.temper == Temperament.Timid ? 1.3f : 1f);
            p.trust = Mathf.Clamp(p.trust - Plugin.TrustLossPerHit.Value * lossMul, 0f, 100f);
            _dirty = true;
        }

        // Раз в секунду: доверие растёт на руках и понемногу восстанавливается; периодическое сохранение.
        public static void Tick()
        {
            if (Time.time < _nextTick) return;
            _nextTick = Time.time + 1f;

            var world = World.Instance;
            if (world == null || World.gat == null) return;
            var gat = World.gat;
            var hand = World.playerController != null ? PlayerController.hand : null;

            if (Plugin.TrustEnabled.Value && Profiles.Count > 0)
            {
                foreach (var kv in Profiles)
                {
                    Handle h = new Handle();
                    h.stableIndex = kv.Key;
                    if (!gat.IsHandleValid(h)) continue;

                    Profile p = kv.Value;
                    float before = p.trust;
                    if (hand != null && hand.IsCarryingGAT(h))
                        p.trust = Mathf.Min(100f, p.trust + Plugin.TrustGainPerSecondCarried.Value);
                    else if (p.trust < Plugin.TrustStart.Value && !p.feral)
                        p.trust = Mathf.Min(Plugin.TrustStart.Value, p.trust + Plugin.TrustRegenPerSecond.Value);
                    if (p.trust != before) _dirty = true;
                }
            }

            TickFeral(world);

            if (_dirty && Time.time >= _nextSave)
            {
                _nextSave = Time.time + 60f;
                try { Save(); } catch (Exception e) { Plugin.Log.LogWarning("[pups] save: " + e.Message); }
            }
        }

        // ---------- бродячие щенки: как игра их видит ----------

        public static bool IsFeral(Handle h)
        {
            Profile p;
            return Profiles.TryGetValue(h.stableIndex, out p) && p.feral;
        }

        public static int FeralCount()
        {
            var world = World.Instance;
            if (world == null || World.gat == null) return 0;
            int n = 0;
            foreach (var kv in Profiles)
            {
                if (!kv.Value.feral) continue;
                Handle h = new Handle();
                h.stableIndex = kv.Key;
                if (World.gat.IsHandleValid(h)) n++;
            }
            return n;
        }

        public static int FeralHungryCount()
        {
            var world = World.Instance;
            if (world == null || World.gat == null) return 0;
            int n = 0;
            foreach (var kv in Profiles)
            {
                if (!kv.Value.feral) continue;
                Handle h = new Handle();
                h.stableIndex = kv.Key;
                if (!World.gat.IsHandleValid(h)) continue;
                GATInstanceInfo info = default(GATInstanceInfo);
                if (World.gat.TryGetInstanceInfoImmediate(h, out info) && info.hunger > 0) n++;
            }
            return n;
        }

        // Пересчитать счётчик детей в игре (патчи вычтут из него бродячих).
        public static void RefreshCareUi()
        {
            try
            {
                var world = World.Instance;
                var ui = world != null ? World.stateDisplayUI : null;
                if (ui != null) Traverse.Create(ui).Method("RefreshTotalPlayerCount").GetValue();
            }
            catch (Exception e) { Plugin.Log.LogWarning("care ui: " + e.Message); }
        }

        // ---------- бродячие щенки ----------

        private static Vector3 _lastCam;
        private static float _lastCamT = -1f, _camSpeed;
        private static readonly Dictionary<ushort, float> NextFlee = new Dictionary<ushort, float>();
        private static readonly Dictionary<ushort, float> NextRoam = new Dictionary<ushort, float>();

        public static void MarkFeral(Handle h)
        {
            Profile p = Get(h);
            p.feral = true;
            p.trust = 5f;
            p.temper = Temperament.Timid;
            p.shoos = 0;
            _dirty = true;
            UppiesBridge.Offend(h, 3600f); // бродячий не просится на ручки
            RefreshCareUi();
            if (Plugin.DebugLog.Value) Plugin.Log.LogInfo("[pups] handle " + h.stableIndex + " is feral now");
        }

        // Волчонка прогнали: доверие падает, а после нескольких раз подряд он уходит из семьи.
        public static void OnShoo(Handle h)
        {
            Profile p = Get(h);
            p.trust = Mathf.Max(0f, p.trust - Plugin.ShooTrustLoss.Value);
            p.shoos++;
            _dirty = true;
            int limit = Plugin.RunawayAfterShoos.Value;
            if (limit > 0 && p.shoos >= limit && !p.feral)
            {
                p.feral = true;
                p.trust = Mathf.Min(p.trust, 10f);
                Plugin.Instance.Toast("Щенок ушёл из семьи...", 4f);
                Plugin.Log.LogInfo("[pups] handle " + h.stableIndex + " ran away from the family");
                UppiesBridge.Offend(h, 3600f);
                RefreshCareUi();
            }
        }

        // Бродячие щенки убегают от игрока; стоя смирно без оружия, можно завоевать доверие.
        private static void TickFeral(World world)
        {
            bool any = false;
            foreach (var kv in Profiles) { if (kv.Value.feral) { any = true; break; } }
            if (!any) return;

            var gat = World.gat;
            var hand = World.playerController != null ? PlayerController.hand : null;
            var cam = Combat.GetCameraPos();
            float now = Time.time;
            if (!cam.HasValue) return;

            if (_lastCamT >= 0f)
                _camSpeed = Vector3.Distance(cam.Value, _lastCam) / Mathf.Max(0.05f, now - _lastCamT);
            _lastCam = cam.Value;
            _lastCamT = now;

            bool armed = false;
            var tool = World.playerController != null ? World.playerController.CurrentTool : null;
            if (tool != null)
            {
                var te = tool.toolEnum;
                armed = te == Tool.ToolEnum.AXE || te == Tool.ToolEnum.SHOVEL;
            }
            bool still = _camSpeed < 0.6f && !armed;

            var promoted = new List<ushort>();
            foreach (var kv in Profiles)
            {
                Profile p = kv.Value;
                if (!p.feral) continue;
                Handle h = new Handle();
                h.stableIndex = kv.Key;
                if (!gat.IsHandleValid(h)) continue;
                var m = gat.GetInstanceMatrixImmediate(h);
                if (!m.HasValue) continue;
                float d = Vector3.Distance(m.Value.GetPosition(), cam.Value);

                if (hand != null && hand.IsCarryingGAT(h))
                {
                    p.trust = Mathf.Min(100f, p.trust + Plugin.BefriendTrustPerSecond.Value * 2f);
                    _dirty = true;
                }
                else if (d <= Plugin.BefriendRadius.Value && still)
                {
                    p.trust = Mathf.Min(100f, p.trust + Plugin.BefriendTrustPerSecond.Value);
                    _dirty = true;
                }
                else if (d <= Plugin.FeralFleeRadius.Value && World.gatFleeHuddleBehavior != null)
                {
                    float next;
                    NextFlee.TryGetValue(kv.Key, out next);
                    if (now >= next)
                    {
                        World.gatFleeHuddleBehavior.Add(h, true, Plugin.FeralFleeSeconds.Value);
                        NextFlee[kv.Key] = now + Plugin.FeralFleeSeconds.Value + 2f;
                    }
                }

                // далеко от игрока бродячий щенок сам бродит по округе
                if (d > Plugin.FeralFleeRadius.Value && World.gatRunRandomlyBehavior != null)
                {
                    float nr;
                    NextRoam.TryGetValue(kv.Key, out nr);
                    if (now >= nr)
                    {
                        World.gatRunRandomlyBehavior.Add(new[] { h });
                        NextRoam[kv.Key] = now + UnityEngine.Random.Range(20f, 40f);
                    }
                }

                if (p.trust >= Plugin.BefriendTrust.Value) promoted.Add(kv.Key);
            }

            foreach (ushort k in promoted)
            {
                Profiles[k].feral = false;
                Profiles[k].shoos = 0;
                _dirty = true;
                Plugin.Instance.Toast("Щенок вам доверился и вернулся в семью", 4f);
                Plugin.Log.LogInfo("[pups] handle " + k + " accepted the player and rejoined the family");
            }
            if (promoted.Count > 0) RefreshCareUi();
        }

        public static void MarkDirty() { _dirty = true; }

        // Смерть волчицы: все теряют доверие; часть дичает, часть уходит из семьи совсем.
        public static void OnMamaDeath()
        {
            var gat = World.gat;
            if (gat == null) return;
            int gone = 0, wild = 0;
            foreach (var kv in Profiles)
            {
                Handle h = new Handle();
                h.stableIndex = kv.Key;
                if (!gat.IsHandleValid(h)) continue;
                var tmpl = gat.GetTemplateFromHandle(h);
                if (tmpl == null || tmpl.name.ToLowerInvariant().Contains("fake")) continue;

                Profile p = kv.Value;
                p.trust = Mathf.Max(0f, p.trust - Plugin.OrphanTrustLoss.Value);
                float k = 1f;
                if (Plugin.TemperamentEnabled.Value)
                    k = p.temper == Temperament.Timid ? 1.5f : (p.temper == Temperament.Brave ? 0.5f : 1f);

                float r = UnityEngine.Random.value;
                float leave = Plugin.OrphanLeaveChance.Value * k;
                float wildEnd = leave + Plugin.OrphanFeralChance.Value * k;
                if (r < leave) { SendAway(h); gone++; }
                else if (r < wildEnd && !p.feral) { MarkFeral(h); wild++; }
            }
            _dirty = true;
            Plugin.Log.LogInfo("[fate] orphans: " + gone + " leave for good, " + wild + " go wild");
            if (gone + wild > 0) Plugin.Instance.Toast("Осиротевшие щенки разбегаются...", 5f);
        }

        // Щенок убегает и исчезает через OrphanLeaveDelay секунд: так он выбывает и из счётчиков.
        public static void SendAway(Handle h)
        {
            Plugin.Instance.StartCoroutine(Plugin.Instance.PupLeaves(h, Plugin.OrphanLeaveDelay.Value));
        }

        // Каждое утро без мамы: слабое доверие превращается в дичание, у бродячих в уход.
        public static void OnNight()
        {
            if (!MamaFate.Absent) return;
            var gat = World.gat;
            if (gat == null) return;
            int gone = 0, wild = 0;
            foreach (var kv in Profiles)
            {
                Handle h = new Handle();
                h.stableIndex = kv.Key;
                if (!gat.IsHandleValid(h)) continue;
                Profile p = kv.Value;
                if (p.feral)
                {
                    if (p.trust < 15f && UnityEngine.Random.value < 0.25f) { SendAway(h); gone++; }
                }
                else if (p.trust < 20f && UnityEngine.Random.value < 0.15f)
                {
                    MarkFeral(h); wild++;
                }
            }
            if (gone + wild > 0)
            {
                _dirty = true;
                Plugin.Log.LogInfo("[fate] night without the mama: " + gone + " left, " + wild + " went wild");
                Plugin.Instance.Toast("За ночь не все щенки остались рядом...", 5f);
            }
        }

        // Бешенство волчицы: все волчата теряют доверие.
        public static void OnMamaFury()
        {
            if (!Plugin.TrustEnabled.Value) return;
            var world = World.Instance;
            if (world == null || World.gat == null) return;
            foreach (var kv in Profiles)
            {
                Handle h = new Handle();
                h.stableIndex = kv.Key;
                if (!World.gat.IsHandleValid(h)) continue;
                kv.Value.trust = Mathf.Max(0f, kv.Value.trust - Plugin.FuryTrustLoss.Value);
            }
            _dirty = true;
        }

        // Убираем профили тех, кого больше нет (умерли). Вызывается только после успешного скана.
        public static void Purge(HashSet<ushort> present)
        {
            var dead = new List<ushort>();
            foreach (ushort k in Profiles.Keys)
                if (!present.Contains(k)) dead.Add(k);
            foreach (ushort k in dead) Profiles.Remove(k);
            if (dead.Count > 0)
            {
                _dirty = true;
                if (Plugin.Verbose.Value) Plugin.Log.LogInfo("[pups] dropped " + dead.Count + " profiles of missing pups");
            }
        }

        // ---------- файл ----------

        private static string SaveName()
        {
            string n = null;
            try
            {
                var world = World.Instance;
                if (world != null && World.worldSerializer != null) n = World.worldSerializer.LastSaveName;
            }
            catch (Exception) { }
            if (string.IsNullOrEmpty(n)) n = "unsaved";
            foreach (char c in Path.GetInvalidFileNameChars()) n = n.Replace(c, '_');
            return n;
        }

        private static string FileFor(string name)
        {
            return Path.Combine(Path.Combine(BepInEx.Paths.ConfigPath, "FamilyTimeFriendlyFire"), name + ".pups.txt");
        }

        private static void EnsureLoaded()
        {
            if (!Plugin.TrustPersist.Value) return;
            string name = SaveName();
            if (name == _loadedFor) return;

            string path = FileFor(name);
            try
            {
                if (File.Exists(path))
                {
                    Profiles.Clear();
                    MamaFate.Absent = false;
                    Load(path);
                }
                else
                {
                    _dirty = true; // новое имя сохранения: профили из памяти запишутся под ним
                }
            }
            catch (Exception e) { Plugin.Log.LogWarning("[pups] load: " + e.Message); }
            _loadedFor = name;
        }

        private static void Load(string path)
        {
            int n = 0;
            foreach (string line in File.ReadAllLines(path))
            {
                string[] f = line.Split(';');
                if (f.Length >= 5 && f[0] == "#mama") // состояние волчицы: #mama;1;x;y;z
                {
                    float px, py, pz;
                    if (f[1] == "1" &&
                        float.TryParse(f[2], NumberStyles.Float, CultureInfo.InvariantCulture, out px) &&
                        float.TryParse(f[3], NumberStyles.Float, CultureInfo.InvariantCulture, out py) &&
                        float.TryParse(f[4], NumberStyles.Float, CultureInfo.InvariantCulture, out pz))
                    {
                        MamaFate.Absent = true;
                        MamaFate.ParkPos = new Vector3(px, py, pz);
                    }
                    continue;
                }
                if (f.Length < 3) continue;
                ushort id; float trust; byte t;
                if (!ushort.TryParse(f[0], out id)) continue;
                if (!float.TryParse(f[1], NumberStyles.Float, CultureInfo.InvariantCulture, out trust)) continue;
                if (!byte.TryParse(f[2], out t) || t > 2) continue;

                var p = new Profile();
                p.trust = Mathf.Clamp(trust, 0f, 100f);
                p.temper = (Temperament)t;
                p.feral = f.Length > 3 && f[3] == "1";
                int shoos = 0;
                if (f.Length > 4) int.TryParse(f[4], out shoos);
                p.shoos = shoos;
                Profiles[id] = p;
                n++;
            }
            Plugin.Log.LogInfo("[pups] loaded " + n + " profiles from " + Path.GetFileName(path));
        }

        public static void Save()
        {
            if (!Plugin.TrustPersist.Value || !_dirty) return;
            string name = _loadedFor ?? SaveName();
            string path = FileFor(name);
            Directory.CreateDirectory(Path.GetDirectoryName(path));

            var lines = new List<string>(Profiles.Count);
            foreach (var kv in Profiles)
                lines.Add(kv.Key + ";" + kv.Value.trust.ToString("F1", CultureInfo.InvariantCulture) + ";" + (byte)kv.Value.temper +
                          ";" + (kv.Value.feral ? 1 : 0) + ";" + kv.Value.shoos);
            if (MamaFate.Absent)
                lines.Add("#mama;1;" + MamaFate.ParkPos.x.ToString("F1", CultureInfo.InvariantCulture) + ";" +
                          MamaFate.ParkPos.y.ToString("F1", CultureInfo.InvariantCulture) + ";" +
                          MamaFate.ParkPos.z.ToString("F1", CultureInfo.InvariantCulture));
            File.WriteAllLines(path, lines.ToArray());
            _dirty = false;
            if (Plugin.Verbose.Value) Plugin.Log.LogInfo("[pups] saved " + lines.Count + " profiles to " + Path.GetFileName(path));
        }
    }

    // ---------------------------------------------------------------------
    // Ночные налёты: вечером к лагерю может выйти кабан (шанс растёт с числом раненых волчат)
    // ---------------------------------------------------------------------
    internal static class Raid
    {
        private static float _nextTick;
        private static int _decidedDay = -1;
        private static float _raidAt = -1f;
        private static bool _noTemplateWarned;

        public static void Tick()
        {
            if (!Plugin.RaidEnabled.Value || Time.time < _nextTick) return;
            _nextTick = Time.time + 5f;

            var world = World.Instance;
            if (world == null || World.dayManager == null || World.gat == null || World.playerController == null) return;
            if (WolfMama.ActiveInstance == null || IsSleeping()) return;

            float t = World.dayManager.CurrentTimeOfDay;
            bool night = t >= Plugin.RaidNightStartHour.Value || t < 6f;
            if (!night) { _raidAt = -1f; return; }

            int day = World.dayManager.Day;
            if (_decidedDay != day)
            {
                _decidedDay = day;
                int wounded = Injury.WoundedCount();
                float chance = Mathf.Clamp(Plugin.RaidBaseChance.Value + Plugin.RaidPerWounded.Value * wounded +
                                           (MamaFate.Absent ? Plugin.RaidAbsentBonus.Value : 0f),
                                           0f, Plugin.RaidMaxChance.Value);
                bool go = UnityEngine.Random.value < chance;
                _raidAt = go ? Time.time + UnityEngine.Random.Range(10f, 40f) : -1f;
                Plugin.Log.LogInfo("[raid] evening of day " + day + ": wounded pups " + wounded + ", chance " +
                    chance.ToString("F2") + " -> " + (go ? "raid" : "quiet night"));
                return;
            }

            if (_raidAt > 0f && Time.time >= _raidAt)
            {
                _raidAt = -1f;
                Spawn(world);
            }
        }

        private static void Spawn(World world)
        {
            var gat = World.gat;
            var mama = WolfMama.ActiveInstance;
            if (mama == null) return;

            Template tmpl = FindTemplate(world);
            if (tmpl == null)
            {
                if (!_noTemplateWarned)
                {
                    _noTemplateWarned = true;
                    Plugin.Log.LogWarning("[raid] шаблон '" + Plugin.RaidTemplate.Value + "' не найден (см. строку [drops] all templates)");
                }
                return;
            }

            int index = gat.GetTemplateIndex(tmpl);
            var hf = World.heightfield;
            Vector3 c = mama.transform.position;
            int spawned = 0;

            for (int i = 0; i < Mathf.Max(1, Plugin.RaidCount.Value); i++)
            {
                for (int attempt = 0; attempt < 10; attempt++)
                {
                    float ang = UnityEngine.Random.value * (float)Math.PI * 2f;
                    float dist = Plugin.RaidDistance.Value * UnityEngine.Random.Range(0.8f, 1.2f);
                    float x = c.x + Mathf.Cos(ang) * dist;
                    float z = c.z + Mathf.Sin(ang) * dist;
                    float y = hf != null ? hf.GetWorldHeight(x, z) : c.y;
                    if (float.IsNaN(y) || float.IsInfinity(y) || Mathf.Abs(y - c.y) > 6f) continue; // обрывы и впадины пропускаем

                    var m = Matrix4x4.TRS(new Vector3(x, y + 0.3f, z),
                                          Quaternion.Euler(0f, UnityEngine.Random.value * 360f, 0f), Vector3.one);
                    gat.CreateInstance(m, index, null);
                    spawned++;
                    break;
                }
            }

            if (spawned > 0)
            {
                Plugin.Instance.Toast("Из темноты слышен рёв кабана!", 5f);
                Plugin.Log.LogInfo("[raid] spawned " + spawned + " x '" + tmpl.name + "' (" + tmpl.faction + ") around the camp");
            }
        }

        // Шаблон налётчика: предпочитаем враждебный (HOSTILE) с нужным словом в названии.
        private static Template FindTemplate(World world)
        {
            var entries = World.gat.GetTemplateEntries();
            if (entries == null) return null;

            string needle = (Plugin.RaidTemplate.Value ?? "boar").Trim().ToLowerInvariant();
            Template any = null;
            for (int i = 0; i < entries.Count; i++)
            {
                var t = entries[i].template;
                if (t == null || t.faction == Faction.ITEM) continue;
                if (!t.name.ToLowerInvariant().Contains(needle)) continue;
                if (t.faction == Faction.HOSTILE) return t;
                if (any == null) any = t;
            }
            return any;
        }

        private static bool _gsTried;
        private static PropertyInfo _gsInstance, _gsSleeping;

        private static bool IsSleeping()
        {
            try
            {
                if (!_gsTried)
                {
                    _gsTried = true;
                    var gs = Util.FindType("family.GameSession");
                    if (gs != null)
                    {
                        _gsInstance = AccessTools.Property(gs, "Instance");
                        _gsSleeping = AccessTools.Property(gs, "IsSleeping");
                    }
                }
                if (_gsInstance == null || _gsSleeping == null) return false;
                object inst = _gsInstance.GetValue(null, null);
                if (inst == null) return false;
                object v = _gsSleeping.GetValue(inst, null);
                return v is bool && (bool)v;
            }
            catch (Exception) { return false; }
        }
    }

    // ---------------------------------------------------------------------
    // Падения: после броска/выпускания следим за волчонком и считаем урон при приземлении
    // ---------------------------------------------------------------------
    internal static class Falls
    {
        public static bool InThrow;

        private sealed class Flight
        {
            public Handle h;
            public float start;
            public float lastT = -1f;
            public Vector3 lastPos;
            public float peakY = float.MinValue;
            public float maxDown;
            public int settled;
        }

        private static readonly Dictionary<ushort, Flight> Flights = new Dictionary<ushort, Flight>();
        private static readonly Dictionary<ushort, float> ReleasedAt = new Dictionary<ushort, float>();

        // Выпускал или бросал ли игрок этого волчонка в последние seconds секунд.
        public static bool RecentlyReleased(Handle h, float seconds)
        {
            float t;
            return ReleasedAt.TryGetValue(h.stableIndex, out t) && Time.time - t <= seconds;
        }
        private static readonly List<ushort> Done = new List<ushort>();
        private static HandService _hand;

        public static void Tick()
        {
            if (!Plugin.FallsEnabled.Value) return;
            var world = World.Instance;
            if (world == null || World.playerController == null || World.gat == null) return;
            var hand = PlayerController.hand;
            if (hand == null) return;

            // подписка на событие "волчонка отпустили" (бросок или просто положили)
            if (!ReferenceEquals(hand, _hand))
            {
                if (_hand != null) _hand.onGATInstanceReleased -= OnReleased;
                _hand = hand;
                _hand.onGATInstanceReleased += OnReleased;
                if (Plugin.Verbose.Value) Plugin.Log.LogInfo("[fall] subscribed to hand release events");
            }
            if (Flights.Count == 0) return;

            float now = Time.time;
            Done.Clear();
            foreach (var kv in Flights)
            {
                Flight f = kv.Value;
                if (now - f.start > Plugin.MaxFlightSeconds.Value || !World.gat.IsHandleValid(f.h))
                {
                    if (Plugin.DebugLog.Value && World.gat.IsHandleValid(f.h))
                        Plugin.Log.LogInfo("[fall] handle " + f.h.stableIndex + " flight tracking timed out (max down speed " + f.maxDown.ToString("F1") + ")");
                    Done.Add(kv.Key);
                    continue;
                }
                if (hand.IsCarryingGAT(f.h)) { Done.Add(kv.Key); continue; } // поймали обратно

                if (f.lastT >= 0f && now - f.lastT < 0.06f) continue;
                var m = World.gat.GetInstanceMatrixImmediate(f.h);
                if (!m.HasValue) continue;
                Vector3 pos = m.Value.GetPosition();

                if (f.lastT >= 0f)
                {
                    float dt = now - f.lastT;
                    float vy = (pos.y - f.lastPos.y) / dt;
                    f.maxDown = Mathf.Max(f.maxDown, -vy);
                    f.peakY = Mathf.Max(f.peakY, pos.y);
                    f.settled = Mathf.Abs(vy) < 1.2f ? f.settled + 1 : 0;

                    // приземлился: уже падал быстрее 3 м/с и теперь почти не двигается по вертикали
                    if (now - f.start > 0.2f && f.maxDown > 3f && f.settled >= 2)
                    {
                        Land(f, pos);
                        Done.Add(kv.Key);
                        continue;
                    }
                }
                else
                {
                    f.peakY = pos.y;
                }
                f.lastPos = pos;
                f.lastT = now;
            }
            foreach (ushort k in Done) Flights.Remove(k);
        }

        private static void OnReleased(Handle h)
        {
            try
            {
                var world = World.Instance;
                if (world == null || World.gat == null) return;
                var tmpl = World.gat.GetTemplateFromHandle(h);
                if (tmpl == null || tmpl.faction != Faction.PLAYER) return;
                if (tmpl.name.ToLowerInvariant().Contains("fake")) return;

                ReleasedAt[h.stableIndex] = Time.time;

                var f = new Flight();
                f.h = h;
                f.start = Time.time;
                Flights[h.stableIndex] = f;
            }
            catch (Exception e) { Plugin.Log.LogWarning("fall: " + e.Message); }
        }

        private static void Land(Flight f, Vector3 pos)
        {
            float drop = Mathf.Max(0f, f.peakY - pos.y);
            float speedDmg = Mathf.Max(0f, f.maxDown - Plugin.SafeFallSpeed.Value) * Plugin.DamagePerSpeed.Value;
            float heightDmg = Mathf.Max(0f, drop - Plugin.SafeFallHeight.Value) * Plugin.DamagePerMeter.Value;
            int dmg = Mathf.CeilToInt(Mathf.Max(speedDmg, heightDmg));

            if (Plugin.Verbose.Value)
                Plugin.Log.LogInfo("[fall] handle " + f.h.stableIndex + " landed: drop " + drop.ToString("F1") +
                    " m, max speed " + f.maxDown.ToString("F1") + " m/s -> damage " + dmg);

            if (dmg > 0) Combat.HurtFromFall(f.h, pos, dmg);
        }
    }

    // ---------------------------------------------------------------------
    // Котёл: мгновенная гибель брошенного волчонка
    // ---------------------------------------------------------------------
    internal static class Cauldron
    {
        public static void OnQueued(CauldronLogicManager mgr, Handle h)
        {
            if (!Plugin.FryEnabled.Value) return;
            var dict = Traverse.Create(mgr).Field("pendingHotWaterHandles").GetValue<System.Collections.IDictionary>();
            if (dict == null) return;

            // в очередь "париться" он попадает только если котёл горячий (вода и дрова, суп ещё не готов)
            bool hot = false;
            foreach (System.Collections.DictionaryEntry e in dict)
            {
                var set = e.Value as HashSet<Handle>;
                if (set != null && set.Contains(h)) { hot = true; break; }
            }
            if (!hot) return;

            if (Plugin.FryOnlyThrown.Value && Plugin.FallsEnabled.Value &&
                !Falls.RecentlyReleased(h, Plugin.FryWindowSeconds.Value)) return;

            var world = World.Instance;
            if (world == null || World.gat == null) return;
            var tmpl = World.gat.GetTemplateFromHandle(h);
            if (tmpl == null || tmpl.faction != Faction.PLAYER || tmpl.name.ToLowerInvariant().Contains("fake")) return;

            // убираем из очереди "париться"
            foreach (System.Collections.DictionaryEntry e in dict)
            {
                var set = e.Value as HashSet<Handle>;
                if (set != null) set.Remove(h);
            }

            var m = World.gat.GetInstanceMatrixImmediate(h);
            Vector3 pos = m.HasValue ? m.Value.GetPosition() : Vector3.zero;
            Plugin.Log.LogInfo("[cauldron] pup " + h.stableIndex + " fell into the boiling pot");
            Combat.Fry(h, pos, Plugin.FryDamage.Value);
        }
    }

    // ---------------------------------------------------------------------
    // Мост к моду Pup Traits (если установлен): его черты задают характер волчонка в нашем моде.
    // Читаем только то, что нужно, через рефлексию; при любой ошибке мост выключается сам.
    // ---------------------------------------------------------------------
    internal static class TraitsBridge
    {
        // значения флагов FamilyTimeMods.PupTraits.Trait
        public const int Brave = 2, Shy = 4, Scared = 8, Clingy = 32, Violent = 8192;
        private static bool _tried, _ok, _failedLogged;
        private static Type _pluginType;
        private static MethodInfo _profileMethod;
        private static FieldInfo _traitsField;

        private static bool Init()
        {
            if (!Plugin.LinkMods.Value) return false;
            if (_tried) return _ok;
            _tried = true;
            try
            {
                _pluginType = Util.FindType("FamilyTimeMods.PupTraits.PupTraitsPlugin");
                var profType = Util.FindType("FamilyTimeMods.PupTraits.PupProfile");
                if (_pluginType == null || profType == null)
                {
                    Plugin.Log.LogInfo("[traits] Pup Traits не найден, характер выбирается случайно");
                    return false;
                }
                _profileMethod = AccessTools.Method(_pluginType, "Profile", new Type[] { typeof(Handle) });
                _traitsField = AccessTools.Field(profType, "Traits");
                _ok = _profileMethod != null && _traitsField != null;
                Plugin.Log.LogInfo(_ok ? "[traits] Pup Traits найден, черты используются"
                                       : "[traits] Pup Traits найден, но его API не распознан: характер случайный");
            }
            catch (Exception e) { Plugin.Log.LogWarning("[traits] init: " + e.Message); }
            return _ok;
        }

        // Битовая маска черт волчонка из Pup Traits.
        public static bool TryGetBits(Handle h, out int bits)
        {
            bits = 0;
            if (!Plugin.UsePupTraits.Value || !Init()) return false;
            try
            {
                object inst = Traverse.Create(_pluginType).Property("Current").GetValue();
                if (inst == null) return false;
                object prof = _profileMethod.Invoke(inst, new object[] { h });
                if (prof == null) return false;
                bits = Convert.ToInt32(_traitsField.GetValue(prof));
                return true;
            }
            catch (Exception e)
            {
                if (!_failedLogged) { _failedLogged = true; Plugin.Log.LogWarning("[traits] " + e.Message + ": мост выключен"); }
                _ok = false;
                return false;
            }
        }

        public static bool HasTrait(Handle h, int flag)
        {
            int bits;
            return TryGetBits(h, out bits) && (bits & flag) != 0;
        }

        public static bool TryGetTemperament(Handle h, out Temperament t)
        {
            t = Temperament.Normal;
            int bits;
            if (!TryGetBits(h, out bits)) return false;
            bool brave = (bits & Brave) != 0;
            bool timid = (bits & (Shy | Scared)) != 0;
            t = timid && !brave ? Temperament.Timid : (brave && !timid ? Temperament.Brave : Temperament.Normal);
            return true;
        }
    }

    // ---------------------------------------------------------------------
    // Бродячие щенки: появляются, когда семья истреблена
    // ---------------------------------------------------------------------
    internal static class Strays
    {
        private static int _emptyScans;
        private static float _spawnAt = -1f;
        private static bool _spawned;

        // Вызывается после каждого скана семьи (раз в RescanSeconds).
        public static void OnFamilyCount(int realCount)
        {
            if (!Plugin.StraysEnabled.Value) return;
            if (realCount > 0)
            {
                _emptyScans = 0;
                _spawnAt = -1f;
                _spawned = false;
                return;
            }
            if (_spawned) return;

            // два пустых скана подряд: исключаем момент загрузки игры
            if (++_emptyScans >= 2 && _spawnAt < 0f)
            {
                _spawnAt = Time.time + Plugin.StrayDelaySeconds.Value;
                Plugin.Log.LogInfo("[strays] family is gone; stray pups appear in " + Plugin.StrayDelaySeconds.Value.ToString("F0") + "s");
            }
        }

        public static void Tick()
        {
            if (_spawnAt < 0f || Time.time < _spawnAt) return;
            _spawnAt = -1f;
            _spawned = true;
            try { Spawn(); }
            catch (Exception e) { Plugin.Log.LogWarning("strays: " + e.Message); }
        }

        private static void Spawn()
        {
            var world = World.Instance;
            var mama = WolfMama.ActiveInstance;
            if (world == null || World.gat == null || mama == null) return;

            // шаблон волчонка: фракция PLAYER, не служебный
            Template tmpl = null;
            var entries = World.gat.GetTemplateEntries();
            for (int i = 0; entries != null && i < entries.Count; i++)
            {
                var t = entries[i].template;
                if (t == null || t.faction != Faction.PLAYER) continue;
                if (t.name.ToLowerInvariant().Contains("fake")) continue;
                tmpl = t;
                break;
            }
            if (tmpl == null) { Plugin.Log.LogWarning("[strays] шаблон волчонка не найден"); return; }

            int index = World.gat.GetTemplateIndex(tmpl);
            var hf = World.heightfield;
            Vector3 c = mama.transform.position;
            int spawned = 0;

            for (int i = 0; i < Mathf.Max(1, Plugin.StrayCount.Value); i++)
            {
                for (int attempt = 0; attempt < 10; attempt++)
                {
                    float ang = UnityEngine.Random.value * (float)Math.PI * 2f;
                    float dist = Plugin.StrayDistance.Value * UnityEngine.Random.Range(0.8f, 1.2f);
                    float x = c.x + Mathf.Cos(ang) * dist;
                    float z = c.z + Mathf.Sin(ang) * dist;
                    float y = hf != null ? hf.GetWorldHeight(x, z) : c.y;
                    if (float.IsNaN(y) || float.IsInfinity(y) || Mathf.Abs(y - c.y) > 6f) continue;

                    var m = Matrix4x4.TRS(new Vector3(x, y + 0.3f, z),
                                          Quaternion.Euler(0f, UnityEngine.Random.value * 360f, 0f), Vector3.one);
                    World.gat.CreateInstance(m, index, h => Pups.MarkFeral(h));
                    spawned++;
                    break;
                }
            }

            if (spawned > 0)
            {
                Plugin.Instance.Toast("По лесу бродят чужие щенки...", 5f);
                Plugin.Log.LogInfo("[strays] spawned " + spawned + " x '" + tmpl.name + "' as feral");
            }
        }
    }

    // ---------------------------------------------------------------------
    // Прогнать: клавиша, волчонок убегает, волчица недовольна
    // ---------------------------------------------------------------------
    internal static class Shoo
    {
        private static float _next;

        public static void Tick()
        {
            if (!Plugin.ShooEnabled.Value) return;
            var kb = Keyboard.current;
            if (kb == null || !kb[Plugin.ShooKey.Value].wasPressedThisFrame) return;
            if (Time.time < _next || Cursor.lockState != CursorLockMode.Locked) return;

            var world = World.Instance;
            if (world == null || World.playerController == null) return;
            var hand = PlayerController.hand;
            if (hand == null || hand.Camera == null) return;
            _next = Time.time + 1.5f;

            Transform cam = hand.Camera.transform;
            Vector3 dir = cam.forward;
            float r = Plugin.ShooRadius.Value;
            Vector3 right = Vector3.Cross(Vector3.up, dir);
            if (right.sqrMagnitude < 1e-4f) right = Vector3.right;
            right.Normalize();
            Vector3 up = Vector3.Cross(dir, right).normalized;

            Vector3[] offsets = { Vector3.zero, right * r, -right * r, up * r, -up * r };
            var seen = new HashSet<ushort>();
            int count = 0;
            foreach (Vector3 off in offsets)
            {
                World.RaycastGATInstances(cam.position + off, dir, Plugin.ShooReach.Value,
                    cands => count += OnCandidates(cands, seen));
            }
        }

        private static int OnCandidates(World.GATInstanceRaycastCandidate[] cands, HashSet<ushort> seen)
        {
            if (cands == null) return 0;
            var world = World.Instance;
            if (world == null || World.gat == null) return 0;
            int n = 0;

            foreach (var c in cands)
            {
                if (!c.IsValid || c.Faction != Faction.PLAYER) continue;
                Handle h = c.Handle;
                if (!seen.Add(h.stableIndex)) continue;
                var tmpl = World.gat.GetTemplateFromHandle(h);
                if (tmpl == null || tmpl.name.ToLowerInvariant().Contains("fake")) continue;

                if (World.gatFleeHuddleBehavior != null) World.gatFleeHuddleBehavior.Add(h, true, 12f);
                Combat.PlaySoundFromList(h, c.candidateHeadPos, Combat.ParseGroups(Plugin.OffendedSounds.Value));
                Pups.OnShoo(h);
                try { UppiesBridge.Offend(h, Plugin.OffendedCooldown.Value); } catch (Exception) { }
                n++;
                if (Plugin.DebugLog.Value) Plugin.Log.LogInfo("[shoo] handle " + h.stableIndex + " was driven off");
            }

            if (n > 0) Combat.ShooReaction();
            return n;
        }
    }

    // ---------------------------------------------------------------------
    // Судьба волчицы: смерть и полное отсутствие.
    // Объект волчицы удалять НЕЛЬЗЯ (игра без него падает на утреннем пробуждении). Поэтому она уходит
    // в лес обычной командой движения, потом её скрывают, а звать её обратно блокируется.
    // ---------------------------------------------------------------------
    internal static class MamaFate
    {
        public static bool Absent;          // сохраняется в файле профилей
        public static Vector3 ParkPos;      // куда она ушла
        public static bool IssuingOwnMove;  // наша команда движения: патч её пропускает

        private static bool _hidden;
        private static float _deathAt, _nextCheck;

        public static void Die(WolfMama mama)
        {
            if (Absent) return;
            Absent = true;
            _hidden = false;
            _deathAt = Time.time;

            Plugin.Instance.Toast("Волчица ушла из семьи навсегда...", 7f);
            Plugin.Log.LogInfo("[fate] the mama is gone for good");

            Combat.ShockPupsOnly();
            Pups.OnMamaDeath();

            bool remains = string.Equals(Plugin.MamaDeathMode.Value, "Remains", StringComparison.OrdinalIgnoreCase);
            if (remains)
            {
                // она остаётся на месте: мясо для супа, модель скрыта (объект и симуляция остаются)
                ParkPos = mama.transform.position;
                Combat.DropMeatAmount(ParkPos, Plugin.RemainsMeatCount.Value);
                Hide(mama);
                Plugin.Log.LogInfo("[fate] the mama's remains are left on the spot");
            }
            else
            {
                WalkAway(mama);
            }
            Pups.MarkDirty();
        }

        // Раз в секунду: пока идёт - ждём; далеко от игрока или через 90 с - скрываем; потом сторожим.
        public static void Tick()
        {
            if (!Absent || Time.time < _nextCheck) return;
            _nextCheck = Time.time + 1f;

            var mama = WolfMama.ActiveInstance;
            if (mama == null) return;
            var cam = Combat.GetCameraPos();

            if (!_hidden)
            {
                bool far = cam.HasValue &&
                           Vector3.Distance(mama.transform.position, cam.Value) > Plugin.MamaHideDistance.Value;
                if (far || Time.time - _deathAt > 90f) Hide(mama);
                return;
            }

            // кто-то увёл её от места ухода (другой мод): возвращаем
            if (ParkPos != Vector3.zero && Vector3.Distance(mama.transform.position, ParkPos) > 25f)
                WalkTo(mama, ParkPos);
        }

        public static void OnWake()
        {
            Pups.OnNight();
        }

        private static bool WalkAway(WolfMama mama)
        {
            Vector3 c = mama.transform.position;
            float far = Mathf.Max(60f, Plugin.MamaWalkAwayDistance.Value);
            var hf = World.heightfield;
            for (int attempt = 0; attempt < 24; attempt++)
            {
                float ang = UnityEngine.Random.value * (float)Math.PI * 2f;
                float dist = far * UnityEngine.Random.Range(0.9f, 1.3f);
                float x = c.x + Mathf.Cos(ang) * dist;
                float z = c.z + Mathf.Sin(ang) * dist;
                float y = hf != null ? hf.GetWorldHeight(x, z) : c.y;
                if (float.IsNaN(y) || float.IsInfinity(y) || Mathf.Abs(y - c.y) > 25f) continue;

                ParkPos = new Vector3(x, y, z);
                return WalkTo(mama, ParkPos);
            }
            Plugin.Log.LogWarning("[fate] не нашёл места, куда ей уйти: скрою на месте");
            ParkPos = c;
            return false;
        }

        private static bool WalkTo(WolfMama mama, Vector3 pos)
        {
            try
            {
                Handle h;
                if (!mama.TryGetHandle(out h)) return false;
                var cmd = World.gatCommandManager;
                var mover = cmd != null ? cmd.GetCommand<GATMoveBehavior>() : null;
                if (mover == null) return false;

                IssuingOwnMove = true;
                try { mover.CommandMove(new[] { h }, pos, 3, false); }
                finally { IssuingOwnMove = false; }
                return true;
            }
            catch (Exception e)
            {
                Plugin.Log.LogWarning("[fate] walk: " + e.Message);
                return false;
            }
        }

        // Скрываем модель волчицы (объект и симуляция остаются, игра без них падает).
        private static void Hide(WolfMama mama)
        {
            int n = 0;
            foreach (Renderer r in mama.GetComponentsInChildren<Renderer>(true)) { r.enabled = false; n++; }
            _hidden = true;
            Plugin.Log.LogInfo("[fate] the mama is hidden (" + n + " renderers off)");
        }
    }
}
