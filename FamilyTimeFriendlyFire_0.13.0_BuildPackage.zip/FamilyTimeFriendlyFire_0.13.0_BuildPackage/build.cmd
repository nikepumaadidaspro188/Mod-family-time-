@echo off
setlocal
set "GAME_DIR=F:\family_time\family_time_ep3\family_time_ep3_dx11"
set "MANAGED=%GAME_DIR%\FamilyTime_Data\Managed"
echo Checking paths...
if not exist "%GAME_DIR%\BepInEx\core\BepInEx.dll" (
  echo ERROR: BepInEx.dll not found. Check GAME_DIR in build.cmd.
  pause
  exit /b 1
)
if not exist "%MANAGED%\Assembly-CSharp.dll" (
  echo ERROR: Assembly-CSharp.dll not found. Check the *_Data folder name in build.cmd and csproj.
  pause
  exit /b 1
)
if not exist "%MANAGED%\UnityEngine.IMGUIModule.dll" (
  echo ERROR: UnityEngine.IMGUIModule.dll not found in Managed.
  pause
  exit /b 1
)
echo Building Family Time - Friendly Fire 0.13.0...
dotnet build "%~dp0FamilyTimeFriendlyFire.csproj" -c Release
if errorlevel 1 (
  echo Build failed. Send the FULL output above.
  pause
  exit /b 1
)
echo Build succeeded. DLL: "%~dp0dist\FamilyTimeFriendlyFire.dll"
pause
